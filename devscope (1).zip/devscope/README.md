# DevScope – All-in-One Web Toolkit

A professional, production-ready Chrome Extension (Manifest V3) for web developers, frontend developers, SEO professionals, and website designers.

## Features

### 🔧 Core Tools

| Tool | Description |
|------|-------------|
| **Page Overview** | URL, title, stats, resource counts, technology summary |
| **CSS Studio** | Live CSS injection with per-site profiles, element picker, class injector |
| **Element Inspector** | DevTools-style element inspection with computed styles and box model |
| **Link Grabber** | Extract, filter, search, group, and export all page links |
| **Meta Inspector** | View all meta tags including Open Graph, Twitter Card, hreflang |
| **SEO Inspector** | On-page SEO audit with health score and actionable checks |
| **Images Inspector** | List all images with format, dimensions, alt text analysis |
| **Headers & Redirects** | URL info, security state, and external header analysis links |
| **Technology Detector** | CMS, frameworks, analytics, CDN, and library detection |
| **Performance** | Navigation timing, resource analysis, Core Web Vitals |
| **Accessibility** | WCAG-related checks with visual outline tools |
| **DOM Utilities** | Toggle CSS, images, and visual element outlines |
| **Storage & Cookies** | Inspect localStorage, sessionStorage, and cookies |
| **Developer Utilities** | Color picker, font inspector, mobile-friendliness check |
| **External Tools** | Quick access to PageSpeed, GTmetrix, W3C Validator, etc. |

### ✨ Key Capabilities

- **Custom CSS Injection**: Write and apply CSS to any website in real-time
- **Persistent Site Profiles**: Save CSS, class rules, and preferences per domain
- **Element Picker**: Click any element to inspect, generate selectors, or add classes
- **Smart Link Extraction**: Duplicate detection, domain grouping, tracking parameter removal
- **SEO Health Score**: Local audit with pass/warning/error checks
- **Technology Detection**: Automatic detection of 30+ technologies
- **Dark/Light Themes**: Premium dark mode by default with light mode option
- **Keyboard Shortcuts**: Quick access to common tools
- **Import/Export**: Backup and restore all settings as JSON
- **Privacy First**: No tracking, no analytics, no data collection

## Installation

### Load Unpacked (Development)

1. Open Chrome and navigate to `chrome://extensions/`
2. Enable **Developer mode** (toggle in top-right corner)
3. Click **Load unpacked**
4. Select the `devscope` folder
5. The DevScope icon will appear in your extensions toolbar

### Pin the Extension

Click the puzzle icon (Extensions) in Chrome's toolbar and pin DevScope for quick access.

## Usage

### Opening DevScope

- **Click the extension icon** in Chrome's toolbar
- **Keyboard shortcut**: `Ctrl+Shift+D` (or `Cmd+Shift+D` on Mac)

### Quick Actions

From the popup header, use quick action buttons to instantly access:
- CSS Studio
- Link Grabber
- Meta Inspector
- SEO Inspector
- Technology Detector

### Search / Command Center

Type in the search bar to instantly filter tools. Press `Enter` to open the highlighted tool.

### CSS Studio

1. Open CSS Studio from the tool grid
2. Write your CSS in the editor
3. Click **Apply** to inject it into the current page
4. Click **Save for Site** to persist it for future visits
5. Use the **Element Picker** to click elements and generate selectors
6. Use **Add Class** to dynamically add classes to elements

### Link Grabber

1. Open Link Grabber to see all links on the page
2. Use filters to show internal, external, email, or unique links
3. Search to find specific links
4. Copy all links or export as CSV/TXT

### SEO Inspector

1. Open SEO Inspector to see the audit results
2. Review the health score and individual checks
3. Each check shows pass/warning/error status with details

### Context Menu

Right-click on any page to access:
- Open DevScope
- Inspect Element
- Grab Links
- Inspect Metadata
- Analyze SEO
- Open CSS Studio
- Pick Color
- Open PageSpeed Insights
- Detect Technologies

## Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| `Ctrl+Shift+D` | Toggle DevScope |
| `Ctrl+Shift+L` | Open Link Grabber |
| `Ctrl+Shift+M` | Inspect Metadata |
| `Ctrl+Shift+C` | CSS Element Picker |
| `Ctrl+K` | Focus search (in popup) |
| `Escape` | Close tool panel |

Customize shortcuts at `chrome://extensions/shortcuts`

## Architecture

```
devscope/
├── manifest.json           # MV3 manifest
├── icons/                  # Extension icons (16/32/48/128px)
├── background/
│   └── service-worker.js   # Background service worker
├── content/
│   ├── content.js          # Content script (page interaction)
│   └── content.css         # Content script styles (overlay)
├── popup/
│   ├── popup.html          # Popup UI
│   ├── popup.css           # Premium dark/light theme
│   └── popup.js            # Popup application logic
├── options/
│   ├── options.html        # Settings page
│   └── options.js          # Settings logic
└── shared/
    └── messaging.js        # Shared messaging utilities
```

## Permissions

| Permission | Purpose |
|-----------|---------|
| `activeTab` | Access current tab when popup is opened |
| `scripting` | Inject CSS and scripts into pages |
| `storage` | Store settings and site profiles |
| `tabs` | Query tab information |
| `contextMenus` | Right-click menu integration |
| `commands` | Keyboard shortcut handling |
| `cookies` | Read site cookies for inspection |
| `webNavigation` | Apply persistent CSS on page load |
| `host_permissions` (http/https) | Persistent CSS injection on revisited sites |

## Privacy

- ✅ No analytics or tracking
- ✅ No account required
- ✅ No data sent to external servers
- ✅ All page inspection data stays local
- ✅ External tools only opened when explicitly requested
- ✅ No browsing history collection
- ✅ No remotely hosted executable code

## Browser Compatibility

- ✅ Chrome 88+
- ✅ Edge 88+ (Chromium-based)
- ✅ Brave
- ✅ Vivaldi
- ✅ Opera (Chromium-based)

### Restricted Pages

DevScope cannot run on:
- `chrome://` pages
- Chrome Web Store pages
- `about:` pages
- Other browser internal pages

## Technical Notes

- **Manifest V3** compliant (no deprecated APIs)
- **Service Worker** based (no persistent background page)
- **Content scripts** injected at `document_start` for early CSS application
- **MutationObserver** used for SPA support
- **Virtualized lists** for pages with thousands of links
- **Debounced** operations to prevent performance issues
- **No inline scripts** (CSP compliant)
- **No eval()** in production code paths

## License

MIT License - Free for personal and commercial use.

## Version

**1.0.0** - Initial release
