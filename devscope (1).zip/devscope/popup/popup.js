/**
 * DevScope Popup Application v1.1
 */
(async () => {
  'use strict';

  let currentTab = null;
  let globalEnabled = true;
  let currentTool = null;
  let siteProfile = null;
  let isMobile = false;

  const $ = (s) => document.querySelector(s);
  const $$ = (s) => document.querySelectorAll(s);
  const app = $('#app');
  const domainBadge = $('#domainBadge');
  const globalToggle = $('#globalToggle');
  const pageUrl = $('#pageUrl');
  const pageTitle = $('#pageTitle');
  const pageStatus = $('#pageStatus');
  const searchInput = $('#searchInput');
  const toolGrid = $('#toolGrid');
  const toolPanel = $('#toolPanel');
  const panelTitle = $('#panelTitle');
  const panelContent = $('#panelContent');
  const backBtn = $('#backBtn');
  const settingsPanel = $('#settingsPanel');
  const settingsBackBtn = $('#settingsBackBtn');
  const toastContainer = $('#toastContainer');
  const themeSelect = $('#themeSelect');

  // --- Init ---
  async function init() {
    // Detect mobile
    isMobile = /Android|iPhone|iPad|iPod/i.test(navigator.userAgent) || window.innerWidth <= 480;
    if (isMobile) document.body.classList.add('mobile-mode');

    await loadTheme();
    await loadTabInfo();
    await loadGlobalState();
    setupEvents();
    setupKeyboard();
  }

  async function loadTheme() {
    const d = await chrome.storage.local.get(['theme']);
    const theme = d.theme || 'light'; // default light
    app.className = `theme-${theme}`;
    if (isMobile) app.className = 'theme-light'; // mobile always light initially
    themeSelect.value = theme;
  }

  async function loadTabInfo() {
    try {
      // Check URL params (mobile / full-page mode)
      const params = new URLSearchParams(window.location.search);
      const tabUrlParam = params.get('tabUrl');
      
      let tab;
      if (tabUrlParam) {
        tab = { url: decodeURIComponent(tabUrlParam), title: decodeURIComponent(params.get('tabTitle') || ''), id: parseInt(params.get('tabId')) || null };
      } else {
        const [t] = await chrome.tabs.query({ active: true, currentWindow: true });
        tab = t;
      }
      if (!tab) { showRestricted('No active tab'); return; }
      currentTab = tab;

      if (isRestrictedUrl(tab.url)) { showRestricted('Restricted page'); domainBadge.textContent = 'Restricted'; pageUrl.textContent = tab.url || ''; pageTitle.textContent = tab.title || ''; return; }

      const domain = getDomain(tab.url);
      domainBadge.textContent = domain;
      pageUrl.textContent = tab.url;
      pageUrl.title = tab.url;
      pageTitle.textContent = tab.title || '';
      const isSecure = tab.url?.startsWith('https:');
      pageStatus.textContent = isSecure ? 'HTTPS' : 'HTTP';
      pageStatus.style.background = isSecure ? 'var(--success)' : 'var(--warning)';

      const pd = await sendBg('getSiteProfile', { domain, url: tab.url });
      siteProfile = pd.domainProfile;
    } catch (e) {
      console.error(e);
      showRestricted('Unable to access page');
    }
  }

  async function loadGlobalState() {
    const d = await sendBg('getGlobalState');
    globalEnabled = d.enabled;
    updateToggle();
  }

  function setupEvents() {
    globalToggle.addEventListener('click', async () => {
      globalEnabled = !globalEnabled;
      updateToggle();
      await sendBg('setGlobalState', { enabled: globalEnabled });
      toast(globalEnabled ? 'Extension enabled' : 'Extension disabled', 'success');
    });

    $('#settingsBtn').addEventListener('click', showSettings);
    settingsBackBtn.addEventListener('click', hideSettings);
    backBtn.addEventListener('click', showDashboard);

    $$('.tool-card').forEach(c => c.addEventListener('click', () => openTool(c.dataset.tool)));
    $$('.quick-btn').forEach(b => b.addEventListener('click', () => openTool(b.dataset.tool)));

    searchInput.addEventListener('input', handleSearch);
    searchInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        const vis = Array.from($$('.tool-card')).filter(c => c.style.display !== 'none');
        if (vis[0]) openTool(vis[0].dataset.tool);
      }
    });

    themeSelect.addEventListener('change', async (e) => {
      app.className = `theme-${e.target.value}`;
      await chrome.storage.local.set({ theme: e.target.value });
    });

    $('#exportBtn').addEventListener('click', handleExport);
    $('#importBtn').addEventListener('click', () => $('#importFile').click());
    $('#importFile').addEventListener('change', handleImport);
    $('#blockedDomainsInput').addEventListener('change', async (e) => {
      const domains = e.target.value.split('\n').map(d => d.trim()).filter(d => d);
      await chrome.storage.local.set({ blockedDomains: domains });
      toast('Blocked domains updated', 'success');
    });

    // Global CSS save
    $('#saveGlobalCSS').addEventListener('click', async () => {
      const css = $('#globalCSSEditor').value;
      await sendBg('saveGlobalCSS', { css });
      toast('Global CSS saved — will apply on all sites', 'success');
    });
  }

  function setupKeyboard() {
    document.addEventListener('keydown', (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') { e.preventDefault(); searchInput.focus(); }
      if (e.key === 'Escape') { if (currentTool) showDashboard(); else if (settingsPanel.style.display !== 'none') hideSettings(); }
    });
  }

  // --- Navigation ---
  function showDashboard() { currentTool = null; toolGrid.style.display = 'grid'; toolPanel.style.display = 'none'; settingsPanel.style.display = 'none'; searchInput.value = ''; handleSearch(); }
  function showSettings() { toolGrid.style.display = 'none'; toolPanel.style.display = 'none'; settingsPanel.style.display = 'flex'; loadSettings(); }
  function hideSettings() { settingsPanel.style.display = 'none'; toolGrid.style.display = 'grid'; }

  async function openTool(name) {
    currentTool = name;
    toolGrid.style.display = 'none'; toolPanel.style.display = 'flex'; settingsPanel.style.display = 'none';
    const titles = { overview:'Page Overview', css:'CSS Studio', inspector:'Element Inspector', links:'Link Grabber', meta:'Meta Inspector', seo:'SEO Inspector', images:'Images', headers:'Headers', technologies:'Tech Detector', performance:'Performance', accessibility:'Accessibility', dom:'DOM Utils', storage:'Storage & Cookies', utilities:'Utilities', external:'External Tools' };
    panelTitle.textContent = titles[name] || name;
    panelContent.innerHTML = '<div class="loading-dots"><span></span><span></span><span></span></div>';

    const renderers = { overview:renderOverview, css:renderCSS, inspector:renderInspector, links:renderLinks, meta:renderMeta, seo:renderSEO, images:renderImages, headers:renderHeaders, technologies:renderTech, performance:renderPerf, accessibility:renderA11y, dom:renderDOM, storage:renderStorage, utilities:renderUtils, external:renderExternal };
    try { await renderers[name]?.(); } catch(e) { panelContent.innerHTML = `<div class="empty-state"><p>Error: ${e.message}</p></div>`; }
  }

  function handleSearch() {
    const q = searchInput.value.toLowerCase().trim();
    $$('.tool-card').forEach(c => {
      const n = c.querySelector('.tool-name').textContent.toLowerCase();
      const d = c.querySelector('.tool-desc').textContent.toLowerCase();
      c.style.display = (!q || n.includes(q) || d.includes(q)) ? '' : 'none';
    });
  }

  // --- Fetch HTML via proxy for Meta/SEO ---
  async function fetchPageHTML() {
    if (!currentTab?.url) return null;
    try {
      const result = await sendBg('fetchHTML', { url: currentTab.url });
      return result?.html || null;
    } catch { return null; }
  }

  function parseHTMLMeta(html) {
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, 'text/html');
    const meta = {};

    meta.title = doc.querySelector('title')?.textContent || '';
    meta.charset = doc.characterSet || doc.querySelector('meta[charset]')?.getAttribute('charset') || '';
    meta.viewport = doc.querySelector('meta[name="viewport"]')?.content || '';
    meta.description = doc.querySelector('meta[name="description"]')?.content || '';
    meta.keywords = doc.querySelector('meta[name="keywords"]')?.content || '';
    meta.author = doc.querySelector('meta[name="author"]')?.content || '';
    meta.generator = doc.querySelector('meta[name="generator"]')?.content || '';
    meta.robots = doc.querySelector('meta[name="robots"]')?.content || '';
    meta.themeColor = doc.querySelector('meta[name="theme-color"]')?.content || '';
    meta.referrer = doc.querySelector('meta[name="referrer"]')?.content || '';
    meta.lang = doc.documentElement?.getAttribute('lang') || '';
    meta.canonical = doc.querySelector('link[rel="canonical"]')?.href || '';

    // Open Graph
    doc.querySelectorAll('meta[property^="og:"]').forEach(m => {
      meta['og:' + m.getAttribute('property').replace('og:', '')] = m.content;
    });

    // Twitter
    doc.querySelectorAll('meta[name^="twitter:"]').forEach(m => {
      meta['twitter:' + m.getAttribute('name').replace('twitter:', '')] = m.content;
    });

    // Hreflang
    meta.hreflangs = [];
    doc.querySelectorAll('link[rel="alternate"][hreflang]').forEach(l => {
      meta.hreflangs.push({ lang: l.getAttribute('hreflang'), href: l.href });
    });

    // Icons
    meta.icons = [];
    doc.querySelectorAll('link[rel*="icon"]').forEach(l => {
      meta.icons.push({ rel: l.rel, href: l.href });
    });
    meta.manifest = doc.querySelector('link[rel="manifest"]')?.href || '';

    // Structured data
    meta.structuredData = [];
    doc.querySelectorAll('script[type="application/ld+json"]').forEach(s => {
      try { meta.structuredData.push(JSON.parse(s.textContent)); } catch { meta.structuredData.push({ error: 'Invalid JSON', raw: s.textContent?.substring(0, 200) }); }
    });

    // Headings
    meta.headings = {};
    ['h1','h2','h3','h4','h5','h6'].forEach(h => {
      const els = doc.querySelectorAll(h);
      meta.headings[h] = { count: els.length, texts: Array.from(els).slice(0, 5).map(e => e.textContent?.trim().substring(0, 80)) };
    });

    // Images
    const imgs = doc.querySelectorAll('img');
    meta.imagesTotal = imgs.length;
    meta.imagesNoAlt = Array.from(imgs).filter(i => !i.hasAttribute('alt')).length;

    // Links
    const links = doc.querySelectorAll('a[href]');
    meta.linksTotal = links.length;
    meta.nofollowLinks = Array.from(links).filter(l => (l.rel || '').includes('nofollow')).length;

    // Word count
    const bodyText = doc.body?.textContent || '';
    meta.wordCount = bodyText.trim().split(/\s+/).filter(w => w).length;

    return meta;
  }

  // --- Tool Renderers ---

  async function renderOverview() {
    const data = await sendToContent('getPageData');
    const domStats = await sendToContent('getDOMStats') || {};
    const techs = await sendToContent('getTechnologies') || {};
    if (!data) { panelContent.innerHTML = '<div class="empty-state"><p>Unable to load</p></div>'; return; }

    panelContent.innerHTML = `
      <div class="stats-row">
        <div class="stat-card"><div class="stat-value">${domStats.totalElements||0}</div><div class="stat-label">Elements</div></div>
        <div class="stat-card"><div class="stat-value">${data.linkCount||0}</div><div class="stat-label">Links</div></div>
        <div class="stat-card"><div class="stat-value">${data.imageCount||0}</div><div class="stat-label">Images</div></div>
      </div>
      <div class="section-title">Page Info</div>
      <div class="data-row"><span class="data-label">URL</span><span class="data-value">${esc(data.url)}</span></div>
      <div class="data-row"><span class="data-label">Title</span><span class="data-value">${esc(data.title)}</span><button class="mini-btn" data-copy="${escA(data.title)}">Copy</button></div>
      <div class="data-row"><span class="data-label">Desc</span><span class="data-value">${esc(data.description)||'<em>none</em>'}</span><button class="mini-btn" data-copy="${escA(data.description)}">Copy</button></div>
      <div class="data-row"><span class="data-label">H1</span><span class="data-value">${data.h1Count} found</span></div>
      <div class="data-row"><span class="data-label">Words</span><span class="data-value">${data.wordCount||0}</span></div>
      <div class="data-row"><span class="data-label">Scripts</span><span class="data-value">${domStats.externalScripts||0} ext, ${domStats.inlineScripts||0} inline</span></div>
      ${techs.technologies?.length ? `<div class="section-title">Technologies</div><div class="tech-grid">${techs.technologies.slice(0,8).map(t=>`<div class="tech-item"><span class="tech-confidence ${t.confidence}"></span><span>${esc(t.name)}</span></div>`).join('')}</div>` : ''}
    `;
    attachCopy();
  }

  // --- CSS Studio ---
  async function renderCSS() {
    const globalData = await sendBg('getGlobalCSS');
    const profile = siteProfile || { css: '', domain: getDomain(currentTab?.url) };

    panelContent.innerHTML = `
      <div class="tabs">
        <button class="tab-btn active" data-ct="site">Site CSS</button>
        <button class="tab-btn" data-ct="global">Global CSS</button>
        <button class="tab-btn" data-ct="picker">Picker</button>
        <button class="tab-btn" data-ct="class">Add Class</button>
      </div>
      <div id="cssTabBody">
        ${renderSiteCSSTab(profile)}
      </div>
    `;

    $$('.tab-btn[data-ct]').forEach(b => b.addEventListener('click', () => {
      $$('.tab-btn[data-ct]').forEach(x => x.classList.remove('active'));
      b.classList.add('active');
      const body = $('#cssTabBody');
      if (b.dataset.ct === 'site') body.innerHTML = renderSiteCSSTab(profile);
      else if (b.dataset.ct === 'global') body.innerHTML = renderGlobalCSSTab(globalData.css);
      else if (b.dataset.ct === 'picker') body.innerHTML = renderPickerTab();
      else if (b.dataset.ct === 'class') body.innerHTML = renderClassTab();
      attachCSSEvents(profile, globalData.css);
    }));
    attachCSSEvents(profile, globalData.css);
  }

  function renderSiteCSSTab(profile) {
    return `
      <div class="section-title">CSS for ${esc(profile.domain)}</div>
      <textarea class="css-editor" id="siteCSSEditor" placeholder="/* Custom CSS */">${esc(profile.css||'')}</textarea>
      <div class="css-actions">
        <button class="btn btn-sm btn-primary" id="applySiteCSS">Apply</button>
        <button class="btn btn-sm" id="saveSiteCSS">Save for Site</button>
        <button class="btn btn-sm" id="resetSiteCSS">Reset</button>
        <button class="btn btn-sm" id="copySiteCSS">Copy</button>
      </div>
      <div class="scope-selector" style="margin-top:8px;">
        <div class="scope-option active" data-scope="domain">This Domain</div>
        <div class="scope-option" data-scope="url">This URL</div>
      </div>
    `;
  }

  function renderGlobalCSSTab(css) {
    return `
      <div class="section-title">Global CSS (All Sites)</div>
      <p style="font-size:10px;color:var(--text-muted);margin-bottom:6px;">This CSS loads on EVERY website automatically via the extension.</p>
      <textarea class="css-editor" id="globalCSSEditorPopup" placeholder="/* Applied to all sites */">${esc(css||'')}</textarea>
      <div class="css-actions">
        <button class="btn btn-sm btn-primary" id="saveGlobalCSSPopup">Save Global CSS</button>
        <button class="btn btn-sm" id="applyGlobalCSS">Apply Now</button>
        <button class="btn btn-sm" id="clearGlobalCSS">Clear</button>
      </div>
    `;
  }

  function renderPickerTab() {
    return `
      <div class="section-title">Element Picker for CSS</div>
      <p style="font-size:10px;color:var(--text-secondary);margin-bottom:8px;">Click button, then click any element on page.</p>
      <button class="btn btn-primary btn-sm" id="startCSSPicker">Start Picking</button>
      <div id="cssPickerResult"></div>
    `;
  }

  function renderClassTab() {
    return `
      <div class="section-title">Add Class / ID / Attributes</div>
      <div class="tabs" style="margin-bottom:8px;">
        <button class="tab-btn active" data-clstab="picker">Element Picker</button>
        <button class="tab-btn" data-clstab="manual">Manual Selector</button>
      </div>
      <div id="classTabBody">
        <p style="font-size:10px;color:var(--text-secondary);margin-bottom:8px;">Pick an element, then add class, ID, or attributes.</p>
        <button class="btn btn-primary btn-sm" id="startClassPicker">Pick Element</button>
        <div id="classPickerResult"></div>
      </div>
    `;
  }

  function attachCSSEvents(profile, globalCSS) {
    // Site CSS events
    $('#applySiteCSS')?.addEventListener('click', async () => {
      await sendToContent('injectCSS', { css: $('#siteCSSEditor').value });
      toast('CSS applied', 'success');
    });
    $('#saveSiteCSS')?.addEventListener('click', async () => {
      const css = $('#siteCSSEditor').value;
      const domain = getDomain(currentTab.url);
      await sendBg('saveSiteProfile', { profile: { key: domain, domain, enabled: true, cssEnabled: true, css, rules: siteProfile?.rules || [], classRules: siteProfile?.classRules || [] } });
      siteProfile = { ...siteProfile, css };
      toast('CSS saved for ' + domain, 'success');
    });
    $('#resetSiteCSS')?.addEventListener('click', async () => { await sendToContent('removeCSS'); toast('CSS removed'); });
    $('#copySiteCSS')?.addEventListener('click', () => { copy($('#siteCSSEditor').value); toast('Copied', 'success'); });

    // Global CSS events
    $('#saveGlobalCSSPopup')?.addEventListener('click', async () => {
      const css = $('#globalCSSEditorPopup').value;
      await sendBg('saveGlobalCSS', { css });
      toast('Global CSS saved', 'success');
    });
    $('#applyGlobalCSS')?.addEventListener('click', async () => {
      await sendToContent('injectCSS', { css: $('#globalCSSEditorPopup').value });
      toast('Global CSS applied', 'success');
    });
    $('#clearGlobalCSS')?.addEventListener('click', () => { $('#globalCSSEditorPopup').value = ''; });

    // Picker
    $('#startCSSPicker')?.addEventListener('click', async () => {
      await sendToContent('startElementPicker');
      toast('Click any element');
      chrome.runtime.onMessage.addListener(function h(msg) {
        if (msg.action === 'pickerElementSelected' && msg.mode === 'css') {
          chrome.runtime.onMessage.removeListener(h);
          const r = $('#cssPickerResult');
          if (r) r.innerHTML = `<div class="inspector-result"><div class="selector-display">${esc(msg.data.selector)}</div><button class="btn btn-sm" id="useSelector">Use in Editor</button> <button class="btn btn-sm" id="copySelector">Copy</button></div>`;
          $('#useSelector')?.addEventListener('click', () => { $$('.tab-btn[data-ct]')[0].click(); setTimeout(() => { const e = $('#siteCSSEditor'); if(e) { e.value += `\n${msg.data.selector} {\n  \n}`; e.focus(); } }, 50); });
          $('#copySelector')?.addEventListener('click', () => { copy(msg.data.selector); toast('Copied', 'success'); });
        }
      });
    });

    // Class tab - manual/picker toggle
    $$('[data-clstab]').forEach(b => b.addEventListener('click', () => {
      $$('[data-clstab]').forEach(x => x.classList.remove('active'));
      b.classList.add('active');
      const body = $('#classTabBody');
      if (b.dataset.clstab === 'picker') {
        body.innerHTML = `<p style="font-size:10px;color:var(--text-secondary);margin-bottom:8px;">Pick an element, then add class/ID/attributes.</p><button class="btn btn-primary btn-sm" id="startClassPicker">Pick Element</button><div id="classPickerResult"></div>`;
        attachClassPicker();
      } else {
        body.innerHTML = renderManualClassTab();
        attachManualClassEvents();
      }
    }));

    attachClassPicker();
  }

  function attachClassPicker() {
    $('#startClassPicker')?.addEventListener('click', async () => {
      await sendToContent('startElementPicker');
      toast('Click any element');
      chrome.runtime.onMessage.addListener(function h(msg) {
        if (msg.action === 'pickerElementSelected') {
          chrome.runtime.onMessage.removeListener(h);
          renderClassResult(msg.data);
        }
      });
    });
  }

  function renderClassResult(data) {
    const r = $('#classPickerResult');
    if (!r) return;
    r.innerHTML = `
      <div class="inspector-result">
        <div class="selector-display">${esc(data.selector)}</div>
        <div style="font-size:10px;color:var(--text-muted);margin-bottom:6px;">Classes: ${data.classes.join(' ') || '<em>none</em>'}</div>
        <div class="tabs" style="margin-bottom:6px;">
          <button class="tab-btn active" data-at="class">Class</button>
          <button class="tab-btn" data-at="id">ID</button>
          <button class="tab-btn" data-at="attr">Attribute</button>
        </div>
        <div id="attrTabBody">
          <input type="text" class="storage-edit-input" id="classInput" placeholder="Enter class name" style="margin-bottom:6px;">
          <button class="btn btn-sm btn-primary" id="addClassBtn">Add Class</button>
          <button class="btn btn-sm" id="removeClassBtn">Remove Class</button>
        </div>
        <button class="btn btn-sm" id="copyClasses" style="margin-top:6px;">Copy Classes</button>
        <button class="btn btn-sm" id="copySelector2">Copy Selector</button>
      </div>
    `;

    let attrType = 'class';
    $$('[data-at]').forEach(b => b.addEventListener('click', () => {
      $$('[data-at]').forEach(x => x.classList.remove('active'));
      b.classList.add('active');
      attrType = b.dataset.at;
      const body = $('#attrTabBody');
      if (attrType === 'class') {
        body.innerHTML = `<input type="text" class="storage-edit-input" id="classInput" placeholder="Enter class name" style="margin-bottom:6px;"><button class="btn btn-sm btn-primary" id="addClassBtn">Add Class</button> <button class="btn btn-sm" id="removeClassBtn">Remove</button>`;
        $('#addClassBtn').addEventListener('click', async () => { const v = $('#classInput').value.trim(); if(!v) return; await sendToContent('addClassToElement', { selector: data.selector, className: v }); toast(`Class "${v}" added`, 'success'); });
        $('#removeClassBtn').addEventListener('click', async () => { const v = $('#classInput').value.trim(); if(!v) return; await sendToContent('removeClassFromElement', { selector: data.selector, className: v }); toast(`Class "${v}" removed`); });
      } else if (attrType === 'id') {
        body.innerHTML = `<input type="text" class="storage-edit-input" id="idInput" placeholder="Enter ID" style="margin-bottom:6px;"><button class="btn btn-sm btn-primary" id="setIdBtn">Set ID</button>`;
        $('#setIdBtn').addEventListener('click', async () => {
          const v = $('#idInput').value.trim(); if(!v) return;
          await sendToContent('executeScript', { code: `document.querySelector('${data.selector.replace(/'/g,"\\'")}')?.setAttribute('id','${v.replace(/'/g,"\\'")}')` });
          toast(`ID "${v}" set`, 'success');
        });
      } else {
        body.innerHTML = `<input type="text" class="storage-edit-input" id="attrName" placeholder="Attribute name" style="margin-bottom:4px;"><input type="text" class="storage-edit-input" id="attrVal" placeholder="Attribute value" style="margin-bottom:6px;"><button class="btn btn-sm btn-primary" id="setAttrBtn">Set Attribute</button>`;
        $('#setAttrBtn').addEventListener('click', async () => {
          const n = $('#attrName').value.trim(), v = $('#attrVal').value.trim(); if(!n) return;
          await sendToContent('executeScript', { code: `document.querySelector('${data.selector.replace(/'/g,"\\'")}')?.setAttribute('${n.replace(/'/g,"\\'")}','${v.replace(/'/g,"\\'")}')` });
          toast(`Attribute "${n}" set`, 'success');
        });
      }
    }));

    $('#copyClasses').addEventListener('click', () => { copy(data.classes.join(' ')); toast('Copied', 'success'); });
    $('#copySelector2').addEventListener('click', () => { copy(data.selector); toast('Copied', 'success'); });
  }

  function renderManualClassTab() {
    return `
      <div class="manual-input-group">
        <label>Selector / Element</label>
        <input type="text" id="manualSelector" placeholder="e.g. .header, #main, div.card">
      </div>
      <div class="tabs" style="margin-bottom:6px;">
        <button class="tab-btn active" data-mat="class">Class</button>
        <button class="tab-btn" data-mat="id">ID</button>
        <button class="tab-btn" data-mat="attr">Attribute</button>
      </div>
      <div id="manualAttrBody">
        <div class="manual-input-group">
          <label>Class Name</label>
          <input type="text" id="manualClassName" placeholder="Enter class name">
        </div>
        <button class="btn btn-sm btn-primary" id="manualAddClass">Add Class</button>
        <button class="btn btn-sm" id="manualRemoveClass">Remove Class</button>
      </div>
    `;
  }

  function attachManualClassEvents() {
    let mode = 'class';
    $$('[data-mat]').forEach(b => b.addEventListener('click', () => {
      $$('[data-mat]').forEach(x => x.classList.remove('active'));
      b.classList.add('active');
      mode = b.dataset.mat;
      const body = $('#manualAttrBody');
      if (mode === 'class') {
        body.innerHTML = `<div class="manual-input-group"><label>Class Name</label><input type="text" id="manualClassName" placeholder="Enter class name"></div><button class="btn btn-sm btn-primary" id="manualAddClass">Add Class</button> <button class="btn btn-sm" id="manualRemoveClass">Remove</button>`;
        $('#manualAddClass').addEventListener('click', async () => { const s=$('#manualSelector').value.trim(), c=$('#manualClassName').value.trim(); if(!s||!c) return toast('Fill selector & class','warning'); await sendToContent('addClassToElement',{selector:s,className:c}); toast('Added','success'); });
        $('#manualRemoveClass').addEventListener('click', async () => { const s=$('#manualSelector').value.trim(), c=$('#manualClassName').value.trim(); if(!s||!c) return; await sendToContent('removeClassFromElement',{selector:s,className:c}); toast('Removed'); });
      } else if (mode === 'id') {
        body.innerHTML = `<div class="manual-input-group"><label>ID</label><input type="text" id="manualId" placeholder="Enter ID"></div><button class="btn btn-sm btn-primary" id="manualSetId">Set ID</button>`;
        $('#manualSetId').addEventListener('click', async () => {
          const s=$('#manualSelector').value.trim(), v=$('#manualId').value.trim(); if(!s||!v) return;
          await sendToContent('executeScript',{code:`document.querySelector('${s.replace(/'/g,"\\'")}')?.setAttribute('id','${v.replace(/'/g,"\\'")}')`});
          toast('ID set','success');
        });
      } else {
        body.innerHTML = `<div class="manual-input-group"><label>Attribute Name</label><input type="text" id="manualAttrName" placeholder="e.g. data-custom"></div><div class="manual-input-group"><label>Attribute Value</label><input type="text" id="manualAttrVal" placeholder="e.g. hello"></div><button class="btn btn-sm btn-primary" id="manualSetAttr">Set Attribute</button>`;
        $('#manualSetAttr').addEventListener('click', async () => {
          const s=$('#manualSelector').value.trim(), n=$('#manualAttrName').value.trim(), v=$('#manualAttrVal').value.trim(); if(!s||!n) return;
          await sendToContent('executeScript',{code:`document.querySelector('${s.replace(/'/g,"\\'")}')?.setAttribute('${n.replace(/'/g,"\\'")}','${v.replace(/'/g,"\\'")}')`});
          toast('Attribute set','success');
        });
      }
    }));
  }

  // --- Element Inspector ---
  async function renderInspector() {
    panelContent.innerHTML = `
      <div class="section-title">Element Inspector</div>
      <p style="font-size:10px;color:var(--text-secondary);margin-bottom:8px;">Click button, then click any element.</p>
      <button class="btn btn-primary btn-sm" id="startInspector">Inspect Element</button>
      <div id="inspectorResult"></div>
    `;
    $('#startInspector').addEventListener('click', async () => {
      await sendToContent('startInspector');
      toast('Click any element');
      chrome.runtime.onMessage.addListener(function h(msg) {
        if (msg.action === 'pickerElementSelected' && msg.mode === 'inspect') {
          chrome.runtime.onMessage.removeListener(h);
          renderInspResult(msg.data);
        }
      });
    });
  }

  function renderInspResult(data) {
    const r = $('#inspectorResult');
    r.innerHTML = `
      <div class="inspector-result">
        <div class="selector-display">${esc(data.selector)}</div>
        <div class="tabs"><button class="tab-btn active" data-it="info">Info</button><button class="tab-btn" data-it="styles">Styles</button><button class="tab-btn" data-it="box">Box</button></div>
        <div id="inspDetail">${inspInfo(data)}</div>
        <div class="css-actions" style="margin-top:8px;">
          <button class="btn btn-sm" data-copy="${escA(data.selector)}">Copy Selector</button>
          <button class="btn btn-sm" id="copyHTML">Copy HTML</button>
          <button class="btn btn-sm" id="hideEl">Hide</button>
          <button class="btn btn-sm btn-danger" id="delEl">Delete</button>
        </div>
      </div>
    `;
    r.querySelectorAll('[data-it]').forEach(b => b.addEventListener('click', () => {
      r.querySelectorAll('[data-it]').forEach(x => x.classList.remove('active'));
      b.classList.add('active');
      const d = $('#inspDetail');
      if (b.dataset.it === 'info') d.innerHTML = inspInfo(data);
      else if (b.dataset.it === 'styles') d.innerHTML = inspStyles(data);
      else d.innerHTML = inspBox(data);
    }));
    $('#copyHTML').addEventListener('click', () => { copy(data.outerHTML); toast('HTML copied','success'); });
    $('#hideEl').addEventListener('click', async () => { await sendToContent('hideElement',{selector:data.selector}); toast('Hidden'); });
    $('#delEl').addEventListener('click', async () => { await sendToContent('deleteElement',{selector:data.selector}); toast('Deleted'); });
    attachCopy();
  }

  function inspInfo(d) {
    return `<div class="data-row"><span class="data-label">Tag</span><span class="data-value">${d.tag}</span></div>
    <div class="data-row"><span class="data-label">ID</span><span class="data-value">${d.id||'<em>none</em>'}</span></div>
    <div class="data-row"><span class="data-label">Classes</span><span class="data-value">${d.classes.join(' ')||'<em>none</em>'}</span></div>
    <div class="data-row"><span class="data-label">Size</span><span class="data-value">${Math.round(d.rect?.width)}×${Math.round(d.rect?.height)}px</span></div>
    <div class="data-row"><span class="data-label">Position</span><span class="data-value">(${Math.round(d.rect?.x)}, ${Math.round(d.rect?.y)})</span></div>`;
  }
  function inspStyles(d) {
    const c = d.computed || {};
    return ['display','position','zIndex','color','backgroundColor','fontFamily','fontSize','fontWeight','lineHeight','margin','padding','border'].map(k => `<div class="data-row"><span class="data-label">${k}</span><span class="data-value">${c[k]||''}</span></div>`).join('');
  }
  function inspBox(d) {
    const c = d.computed||{}, r = d.rect||{};
    return `<div style="text-align:center;padding:12px;font-family:var(--font-mono);font-size:10px;">
      <div style="border:2px dashed var(--warning);padding:6px;border-radius:4px;"><div style="color:var(--warning);margin-bottom:3px;">margin: ${c.margin}</div>
      <div style="border:2px solid var(--success);padding:6px;border-radius:4px;"><div style="color:var(--success);margin-bottom:3px;">border: ${c.border}</div>
      <div style="border:2px dashed var(--info);padding:6px;border-radius:4px;"><div style="color:var(--info);margin-bottom:3px;">padding: ${c.padding}</div>
      <div style="border:1px solid var(--text-muted);padding:6px;border-radius:4px;background:var(--bg-input);"><strong>${Math.round(r.width)} × ${Math.round(r.height)}</strong></div>
      </div></div></div></div>`;
  }

  // --- Link Grabber (FIXED: exact URL match for duplicates) ---
  async function renderLinks() {
    panelContent.innerHTML = '<div class="loading-dots"><span></span><span></span><span></span></div>';
    const data = await sendToContent('getLinks');
    if (!data?.links) { panelContent.innerHTML = '<div class="empty-state"><p>No links found</p></div>'; return; }

    const st = await chrome.storage.local.get(['blockedDomains']);
    const blocked = st.blockedDomains || [];
    let links = data.links.filter(l => !blocked.some(b => l.domain.includes(b)));

    panelContent.innerHTML = `
      <div class="stats-row">
        <div class="stat-card"><div class="stat-value">${data.total}</div><div class="stat-label">Total</div></div>
        <div class="stat-card"><div class="stat-value">${links.length}</div><div class="stat-label">After Filter</div></div>
        <div class="stat-card"><div class="stat-value">${links.filter(l=>l.sameOrigin).length}</div><div class="stat-label">Internal</div></div>
      </div>
      <div class="filter-bar">
        <input type="text" class="search-input" id="linkSearch" placeholder="Search links..." style="flex:1;min-width:100px;">
        <span class="filter-chip active" data-lf="all">All</span>
        <span class="filter-chip" data-lf="internal">Internal</span>
        <span class="filter-chip" data-lf="external">External</span>
        <span class="filter-chip" data-lf="email">Email</span>
        <span class="filter-chip" data-lf="no-dup">No Dups</span>
      </div>
      <div class="links-table-wrap">
        <table class="links-table"><thead><tr><th>URL</th><th>Domain</th><th>Type</th></tr></thead><tbody id="linksBody"></tbody></table>
      </div>
      <div class="css-actions" style="margin-top:8px;">
        <button class="btn btn-sm" id="copyAllLinks">Copy All</button>
        <button class="btn btn-sm" id="exportCSV">CSV</button>
        <button class="btn btn-sm" id="exportTXT">TXT</button>
      </div>
    `;

    let filter = 'all', search = '';

    // Exact URL match for duplicates
    function getExactDuplicates(arr) {
      const seen = {};
      return arr.map(l => {
        const isDup = !!seen[l.url];
        seen[l.url] = true;
        return { ...l, isExactDuplicate: isDup };
      });
    }

    function render() {
      let f = links;
      if (filter === 'internal') f = f.filter(l => l.sameOrigin);
      else if (filter === 'external') f = f.filter(l => !l.sameOrigin && l.type !== 'email' && l.type !== 'phone');
      else if (filter === 'email') f = f.filter(l => l.type === 'email');
      else if (filter === 'no-dup') {
        // Only remove EXACT full URL matches
        const processed = getExactDuplicates(f);
        f = processed.filter(l => !l.isExactDuplicate);
      }
      if (search) { const s = search.toLowerCase(); f = f.filter(l => l.url.toLowerCase().includes(s) || l.text.toLowerCase().includes(s) || l.domain.toLowerCase().includes(s)); }
      
      const tbody = $('#linksBody');
      const show = f.slice(0, 200);
      tbody.innerHTML = show.map(l => `<tr><td title="${escA(l.url)}">${esc(l.text||l.url).substring(0,50)}</td><td>${esc(l.domain)}</td><td><span class="badge ${l.type==='external'?'badge-info':l.type==='email'?'badge-warn':'badge-pass'}">${l.type}</span></td></tr>`).join('');
      if (f.length > 200) tbody.innerHTML += `<tr><td colspan="3" style="text-align:center;color:var(--text-muted);">...and ${f.length-200} more</td></tr>`;
    }
    render();

    $$('[data-lf]').forEach(c => c.addEventListener('click', () => { $$('[data-lf]').forEach(x=>x.classList.remove('active')); c.classList.add('active'); filter=c.dataset.lf; render(); }));
    $('#linkSearch').addEventListener('input', e => { search = e.target.value; render(); });
    $('#copyAllLinks').addEventListener('click', () => { copy(links.map(l=>l.url).join('\n')); toast(`Copied ${links.length} links`,'success'); });
    $('#exportCSV').addEventListener('click', () => { download('URL,Text,Domain,Type\n'+links.map(l=>`"${l.url}","${(l.text||'').replace(/"/g,'""')}","${l.domain}","${l.type}"`).join('\n'),'links.csv','text/csv'); toast('Exported','success'); });
    $('#exportTXT').addEventListener('click', () => { download(links.map(l=>l.url).join('\n'),'links.txt','text/plain'); toast('Exported','success'); });
  }

  // --- Meta Inspector (using html.lr7.workers.dev API) ---
  async function renderMeta() {
    panelContent.innerHTML = '<div class="loading-dots"><span></span><span></span><span></span></div><p style="text-align:center;font-size:10px;color:var(--text-muted);margin-top:4px;">Fetching page source...</p>';
    
    // Fetch HTML via proxy
    const html = await fetchPageHTML();
    let meta = {};
    
    if (html) {
      meta = parseHTMLMeta(html);
    } else {
      // Fallback to content script
      const pageData = await sendToContent('getPageData');
      meta.title = pageData?.title || '';
      meta.description = pageData?.description || '';
      meta.canonical = pageData?.canonical || '';
    }

    // Health check
    const health = [
      { name:'Title', ok:!!meta.title, detail:meta.title?`${meta.title.length} chars`:'Missing' },
      { name:'Description', ok:!!meta.description, detail:meta.description?`${meta.description.length} chars`:'Missing' },
      { name:'Canonical', ok:!!meta.canonical, detail:meta.canonical||'Missing' },
      { name:'Viewport', ok:!!meta.viewport, detail:meta.viewport||'Missing' },
      { name:'OG Title', ok:!!meta['og:title'], detail:meta['og:title']||'Missing' },
      { name:'OG Image', ok:!!meta['og:image'], detail:meta['og:image']?'✓':'Missing' },
      { name:'Twitter Card', ok:!!meta['twitter:card'], detail:meta['twitter:card']||'Missing' },
      { name:'Lang', ok:!!meta.lang, detail:meta.lang||'Missing' }
    ];

    panelContent.innerHTML = `
      <div class="section-title">Meta Health</div>
      <div style="display:flex;gap:4px;flex-wrap:wrap;margin-bottom:10px;">
        ${health.map(h=>`<span class="badge ${h.ok?'badge-pass':'badge-warn'}">${h.ok?'✓':'✗'} ${h.name}</span>`).join('')}
      </div>
      <div class="section-title">Basic</div>
      <div class="data-row"><span class="data-label">Title</span><span class="data-value">${esc(meta.title||'')}</span><button class="mini-btn" data-copy="${escA(meta.title)}">Copy</button></div>
      <div class="data-row"><span class="data-label">Desc</span><span class="data-value">${esc(meta.description||'')}</span><button class="mini-btn" data-copy="${escA(meta.description)}">Copy</button></div>
      <div class="data-row"><span class="data-label">Charset</span><span class="data-value">${meta.charset||''}</span></div>
      <div class="data-row"><span class="data-label">Viewport</span><span class="data-value">${esc(meta.viewport||'')}</span></div>
      <div class="data-row"><span class="data-label">Robots</span><span class="data-value">${meta.robots||'<em>not set</em>'}</span></div>
      <div class="data-row"><span class="data-label">Canonical</span><span class="data-value">${esc(meta.canonical||'')}</span><button class="mini-btn" data-copy="${escA(meta.canonical)}">Copy</button></div>
      <div class="data-row"><span class="data-label">Language</span><span class="data-value">${meta.lang||'<em>not set</em>'}</span></div>
      <div class="data-row"><span class="data-label">Author</span><span class="data-value">${esc(meta.author||'')}</span></div>
      <div class="data-row"><span class="data-label">Generator</span><span class="data-value">${esc(meta.generator||'')}</span></div>
      <div class="data-row"><span class="data-label">Keywords</span><span class="data-value">${esc(meta.keywords||'')}</span></div>
      <div class="data-row"><span class="data-label">Theme</span><span class="data-value">${meta.themeColor||''}</span></div>
      ${Object.keys(meta).some(k=>k.startsWith('og:')) ? `
        <div class="section-title">Open Graph</div>
        ${Object.entries(meta).filter(([k])=>k.startsWith('og:')).map(([k,v])=>`<div class="data-row"><span class="data-label">${esc(k)}</span><span class="data-value">${esc(v)}</span><button class="mini-btn" data-copy="${escA(v)}">Copy</button></div>`).join('')}
      ` : ''}
      ${Object.keys(meta).some(k=>k.startsWith('twitter:')) ? `
        <div class="section-title">Twitter Card</div>
        ${Object.entries(meta).filter(([k])=>k.startsWith('twitter:')).map(([k,v])=>`<div class="data-row"><span class="data-label">${esc(k)}</span><span class="data-value">${esc(v)}</span><button class="mini-btn" data-copy="${escA(v)}">Copy</button></div>`).join('')}
      ` : ''}
      <div class="css-actions" style="margin-top:10px;">
        <button class="btn btn-sm" id="copyAllMeta">Copy All</button>
        <button class="btn btn-sm" id="exportMetaJSON">Export JSON</button>
      </div>
      ${html ? '<div style="font-size:9px;color:var(--text-muted);margin-top:6px;text-align:center;">Source fetched via html.lr7.workers.dev proxy</div>' : '<div style="font-size:9px;color:var(--warning);margin-top:6px;text-align:center;">Proxy unavailable — showing limited data from page</div>'}
    `;
    attachCopy();
    $('#copyAllMeta').addEventListener('click', () => { copy(Object.entries(meta).filter(([,v])=>typeof v==='string'&&v).map(([k,v])=>`${k}: ${v}`).join('\n')); toast('Copied','success'); });
    $('#exportMetaJSON').addEventListener('click', () => { download(JSON.stringify(meta,null,2),'metadata.json','application/json'); toast('Exported','success'); });
  }

  // --- SEO Inspector (using html.lr7.workers.dev API) ---
  async function renderSEO() {
    panelContent.innerHTML = '<div class="loading-dots"><span></span><span></span><span></span></div><p style="text-align:center;font-size:10px;color:var(--text-muted);margin-top:4px;">Analyzing SEO via proxy...</p>';
    
    const html = await fetchPageHTML();
    let checks = [];

    if (html) {
      const meta = parseHTMLMeta(html);
      const url = currentTab?.url || '';
      const isHttps = url.startsWith('https:');

      // Title
      if (!meta.title) checks.push({name:'Title',status:'error',detail:'No title tag'});
      else if (meta.title.length < 30) checks.push({name:'Title',status:'warning',detail:`${meta.title.length} chars (aim 50-60)`});
      else if (meta.title.length > 60) checks.push({name:'Title',status:'warning',detail:`${meta.title.length} chars (may truncate)`});
      else checks.push({name:'Title',status:'pass',detail:`${meta.title.length} chars ✓`});

      // Description
      if (!meta.description) checks.push({name:'Meta Description',status:'error',detail:'Missing'});
      else if (meta.description.length < 120) checks.push({name:'Meta Description',status:'warning',detail:`${meta.description.length} chars (aim 150-160)`});
      else if (meta.description.length > 160) checks.push({name:'Meta Description',status:'warning',detail:`${meta.description.length} chars (may truncate)`});
      else checks.push({name:'Meta Description',status:'pass',detail:`${meta.description.length} chars ✓`});

      // Canonical
      checks.push({name:'Canonical URL',status:meta.canonical?'pass':'warning',detail:meta.canonical||'Not set'});

      // H1
      const h1c = meta.headings?.h1?.count || 0;
      if (h1c === 0) checks.push({name:'H1 Tag',status:'error',detail:'No H1 found'});
      else if (h1c > 1) checks.push({name:'H1 Tag',status:'warning',detail:`${h1c} H1 tags (aim: 1)`});
      else checks.push({name:'H1 Tag',status:'pass',detail:`1 found: ${(meta.headings?.h1?.texts?.[0]||'').substring(0,40)}`});

      // Heading structure
      const h = meta.headings || {};
      checks.push({name:'Headings',status:'pass',detail:`H1:${h.h1?.count||0} H2:${h.h2?.count||0} H3:${h.h3?.count||0}`});

      // Images
      if (meta.imagesNoAlt > 0) checks.push({name:'Images Alt',status:'error',detail:`${meta.imagesNoAlt} missing alt`});
      else checks.push({name:'Images Alt',status:'pass',detail:`${meta.imagesTotal} images OK`});

      // HTTPS
      checks.push({name:'HTTPS',status:isHttps?'pass':'error',detail:isHttps?'Secure':'Not HTTPS'});

      // Language
      checks.push({name:'Language',status:meta.lang?'pass':'error',detail:meta.lang||'Missing'});

      // Viewport
      checks.push({name:'Viewport',status:meta.viewport?'pass':'error',detail:meta.viewport?'Set':'Missing'});

      // OG
      checks.push({name:'Open Graph',status:(meta['og:title']&&meta['og:image'])?'pass':'warning',detail:(meta['og:title']&&meta['og:image'])?'OG title & image set':'Missing OG tags'});

      // Twitter
      checks.push({name:'Twitter Card',status:meta['twitter:card']?'pass':'warning',detail:meta['twitter:card']||'Not set'});

      // Structured data
      const sd = meta.structuredData?.length || 0;
      checks.push({name:'Structured Data',status:sd>0?'pass':'warning',detail:sd>0?`${sd} schema(s) found`:'No JSON-LD'});

      // Links
      checks.push({name:'Links',status:'pass',detail:`${meta.linksTotal} total, ${meta.nofollowLinks} nofollow`});

      // Robots
      const noindex = (meta.robots||'').includes('noindex');
      checks.push({name:'Robots',status:noindex?'warning':'pass',detail:noindex?'noindex set':(meta.robots||'Default')});

      // Word count
      checks.push({name:'Content',status:meta.wordCount>300?'pass':'warning',detail:`${meta.wordCount} words`});
    } else {
      checks.push({name:'Source',status:'error',detail:'Could not fetch page source via proxy'});
    }

    const pass = checks.filter(c=>c.status==='pass').length;
    const warn = checks.filter(c=>c.status==='warning').length;
    const err = checks.filter(c=>c.status==='error').length;
    const score = checks.length ? Math.round((pass/checks.length)*100) : 0;
    const sc = score>=80?'var(--success)':score>=50?'var(--warning)':'var(--error)';

    panelContent.innerHTML = `
      <div class="seo-score-card">
        <div class="seo-score-value" style="color:${sc}">${score}</div>
        <div class="seo-score-label">SEO Health</div>
        <div class="seo-score-bar"><div class="seo-score-fill" style="width:${score}%;background:${sc}"></div></div>
        <div style="display:flex;justify-content:center;gap:8px;margin-top:6px;">
          <span class="badge badge-pass">PASS ${pass}</span>
          <span class="badge badge-warn">WARN ${warn}</span>
          <span class="badge badge-error">ERROR ${err}</span>
        </div>
      </div>
      <div class="section-title">Checks</div>
      ${checks.map(c=>`<div class="seo-check-item"><span class="seo-check-status ${c.status}"></span><div class="seo-check-info"><div class="seo-check-name">${esc(c.name)}</div><div class="seo-check-detail">${esc(c.detail)}</div></div><span class="badge badge-${c.status==='pass'?'pass':c.status==='warning'?'warn':'error'}">${c.status.toUpperCase()}</span></div>`).join('')}
      <div style="font-size:9px;color:var(--text-muted);margin-top:6px;text-align:center;">* Local analysis only. Not a Google score.</div>
    `;
  }

  // --- Images ---
  async function renderImages() {
    const data = await sendToContent('getImages');
    if (!data?.images) { panelContent.innerHTML='<div class="empty-state"><p>No images</p></div>'; return; }
    const noAlt = data.images.filter(i=>!i.alt).length;
    panelContent.innerHTML = `
      <div class="stats-row"><div class="stat-card"><div class="stat-value">${data.total}</div><div class="stat-label">Total</div></div><div class="stat-card"><div class="stat-value">${noAlt}</div><div class="stat-label">No Alt</div></div><div class="stat-card"><div class="stat-value">${data.images.filter(i=>i.isExternal).length}</div><div class="stat-label">External</div></div></div>
      <div class="filter-bar"><span class="filter-chip active" data-if="all">All</span><span class="filter-chip" data-if="no-alt">No Alt</span><span class="filter-chip" data-if="external">External</span></div>
      <div class="links-table-wrap" style="max-height:220px;"><table class="links-table"><thead><tr><th>Image</th><th>Alt</th><th>Size</th></tr></thead><tbody id="imgBody"></tbody></table></div>
      <button class="btn btn-sm" id="copyImgURLs" style="margin-top:6px;">Copy All URLs</button>
    `;
    let f='all';
    function render() {
      let imgs = data.images;
      if(f==='no-alt') imgs=imgs.filter(i=>!i.alt);
      else if(f==='external') imgs=imgs.filter(i=>i.isExternal);
      $('#imgBody').innerHTML = imgs.slice(0,100).map(i=>`<tr><td>${i.src?`<img src="${escA(i.src)}" style="width:20px;height:20px;object-fit:cover;border-radius:2px;vertical-align:middle;margin-right:3px;" onerror="this.style.display='none'">`:''}${esc(i.src?.split('/').pop()?.substring(0,25)||'')}</td><td>${esc(i.alt||'<em>none</em>')}</td><td>${i.naturalWidth}×${i.naturalHeight} ${i.format}</td></tr>`).join('');
    }
    render();
    $$('[data-if]').forEach(c=>c.addEventListener('click',()=>{$$('[data-if]').forEach(x=>x.classList.remove('active'));c.classList.add('active');f=c.dataset.if;render();}));
    $('#copyImgURLs').addEventListener('click',()=>{copy(data.images.map(i=>i.src).join('\n'));toast(`Copied ${data.images.length} URLs`,'success');});
  }

  // --- Headers ---
  async function renderHeaders() {
    const data = await sendToContent('getHeaders');
    panelContent.innerHTML = `
      <div class="section-title">Page Info</div>
      <div class="data-row"><span class="data-label">URL</span><span class="data-value">${esc(data.url)}</span><button class="mini-btn" data-copy="${escA(data.url)}">Copy</button></div>
      <div class="data-row"><span class="data-label">Protocol</span><span class="data-value">${data.protocol}</span></div>
      <div class="data-row"><span class="data-label">Security</span><span class="data-value"><span class="badge ${data.securityState==='secure'?'badge-pass':'badge-error'}">${data.securityState}</span></span></div>
      <div class="data-row"><span class="data-label">Host</span><span class="data-value">${data.hostname}</span></div>
      <div class="data-row"><span class="data-label">Referrer</span><span class="data-value">${esc(data.referrer)||'<em>none</em>'}</span></div>
      <div class="section-title">External Tools</div>
      <a class="ext-tool-link" href="https://securityheaders.com/?q=${encodeURIComponent(data.url)}" target="_blank"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg><div><div class="ext-tool-name">Security Headers</div></div></a>
      <a class="ext-tool-link" href="https://httpstatus.io/" target="_blank" style="margin-top:4px;"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg><div><div class="ext-tool-name">HTTP Status Checker</div></div></a>
    `;
    attachCopy();
  }

  // --- Technology Detector ---
  async function renderTech() {
    const data = await sendToContent('getTechnologies');
    if (!data?.technologies?.length) { panelContent.innerHTML='<div class="empty-state"><p>No technologies detected</p></div>'; return; }
    const cats = {};
    data.technologies.forEach(t => { if(!cats[t.category]) cats[t.category]=[]; cats[t.category].push(t); });
    panelContent.innerHTML = `
      <div class="stats-row"><div class="stat-card"><div class="stat-value">${data.total}</div><div class="stat-label">Found</div></div><div class="stat-card"><div class="stat-value">${data.technologies.filter(t=>t.confidence==='high').length}</div><div class="stat-label">High</div></div><div class="stat-card"><div class="stat-value">${Object.keys(cats).length}</div><div class="stat-label">Categories</div></div></div>
      ${Object.entries(cats).map(([cat,techs])=>`<div class="section-title">${esc(cat)}</div><div class="tech-grid">${techs.map(t=>`<div class="tech-item"><span class="tech-confidence ${t.confidence}"></span><span>${esc(t.name)}</span></div>`).join('')}</div>`).join('')}
    `;
  }

  // --- Performance ---
  async function renderPerf() {
    const data = await sendToContent('getPerformance');
    if (!data?.navigation) { panelContent.innerHTML='<div class="empty-state"><p>No data</p></div>'; return; }
    const n = data.navigation;
    const fmt = ms => ms<1000?`${Math.round(ms)}ms`:`${(ms/1000).toFixed(2)}s`;
    const fmtK = b => b<1024?`${b}B`:`${(b/1024).toFixed(1)}KB`;
    panelContent.innerHTML = `
      <div class="section-title">Timing</div>
      <div class="perf-metric"><div class="perf-metric-header"><span class="perf-metric-name">DOMContentLoaded</span><span class="perf-metric-value">${fmt(n.domContentLoaded)}</span></div><div class="perf-bar"><div class="perf-bar-fill ${n.domContentLoaded<1000?'good':n.domContentLoaded<3000?'needs-improvement':'poor'}" style="width:${Math.min(100,n.domContentLoaded/50)}%"></div></div></div>
      <div class="perf-metric"><div class="perf-metric-header"><span class="perf-metric-name">Load</span><span class="perf-metric-value">${fmt(n.loadComplete)}</span></div><div class="perf-bar"><div class="perf-bar-fill ${n.loadComplete<2000?'good':n.loadComplete<5000?'needs-improvement':'poor'}" style="width:${Math.min(100,n.loadComplete/80)}%"></div></div></div>
      <div class="perf-metric"><div class="perf-metric-header"><span class="perf-metric-name">TTFB</span><span class="perf-metric-value">${fmt(n.ttfb)}</span></div><div class="perf-bar"><div class="perf-bar-fill ${n.ttfb<800?'good':'poor'}" style="width:${Math.min(100,n.ttfb/30)}%"></div></div></div>
      <div class="section-title">Resources</div>
      <div class="stats-row"><div class="stat-card"><div class="stat-value">${data.resources.total}</div><div class="stat-label">Requests</div></div><div class="stat-card"><div class="stat-value">${fmtK(data.resources.totalSize)}</div><div class="stat-label">Transfer</div></div><div class="stat-card"><div class="stat-value">${fmtK(n.decodedSize)}</div><div class="stat-label">Decoded</div></div></div>
      <div class="css-actions"><a class="btn btn-sm" href="https://pagespeed.web.dev/report?url=${encodeURIComponent(currentTab.url)}" target="_blank">PageSpeed</a><a class="btn btn-sm" href="https://gtmetrix.com/?url=${encodeURIComponent(currentTab.url)}" target="_blank">GTmetrix</a></div>
    `;
  }

  // --- Accessibility ---
  async function renderA11y() {
    const data = await sendToContent('getAccessibility');
    if (!data) { panelContent.innerHTML='<div class="empty-state"><p>Unable</p></div>'; return; }
    panelContent.innerHTML = `
      <div class="stats-row"><div class="stat-card"><div class="stat-value">${data.total}</div><div class="stat-label">Issues</div></div><div class="stat-card"><div class="stat-value" style="color:var(--error)">${data.errors}</div><div class="stat-label">Errors</div></div><div class="stat-card"><div class="stat-value" style="color:var(--warning)">${data.warnings}</div><div class="stat-label">Warnings</div></div></div>
      <div class="section-title">Issues</div>
      ${data.issues.length===0?'<div class="empty-state"><p>No issues! 🎉</p></div>':''}
      ${data.issues.slice(0,25).map(i=>`<div class="a11y-issue ${i.type}"><span>${i.type==='error'?'❌':'⚠️'}</span><div style="flex:1;"><div style="font-weight:600;">${esc(i.rule)}</div><div style="color:var(--text-muted);margin-top:1px;">${esc(i.message)}</div></div></div>`).join('')}
      <div class="section-title">Outlines</div>
      <div class="dom-toggles">
        <button class="dom-toggle-btn" data-ol="headings">Headings</button>
        <button class="dom-toggle-btn" data-ol="links">Links</button>
        <button class="dom-toggle-btn" data-ol="images">Images</button>
        <button class="dom-toggle-btn" data-ol="buttons">Buttons</button>
        <button class="dom-toggle-btn" data-ol="forms">Forms</button>
        <button class="dom-toggle-btn" id="clearOL">Clear</button>
      </div>
    `;
    $$('[data-ol]').forEach(b=>b.addEventListener('click',async()=>{await sendToContent('outlineElements',{type:b.dataset.ol});b.classList.toggle('active');}));
    $('#clearOL')?.addEventListener('click',async()=>{await sendToContent('clearOutlines');$$('.dom-toggle-btn').forEach(b=>b.classList.remove('active'));});
  }

  // --- DOM Utils ---
  async function renderDOM() {
    const s = await sendToContent('getDOMStats') || {};
    panelContent.innerHTML = `
      <div class="stats-row"><div class="stat-card"><div class="stat-value">${s.totalElements||0}</div><div class="stat-label">Elements</div></div><div class="stat-card"><div class="stat-value">${s.depth||0}</div><div class="stat-label">Depth</div></div><div class="stat-card"><div class="stat-value">${s.iframes||0}</div><div class="stat-label">iFrames</div></div></div>
      <div class="section-title">Toggles</div>
      <div class="dom-toggles">
        <button class="dom-toggle-btn" id="togCSS">Disable CSS</button>
        <button class="dom-toggle-btn" id="togImg">Hide Images</button>
        <button class="dom-toggle-btn" data-ol="all">All Outlines</button>
        <button class="dom-toggle-btn" data-ol="headings">Headings</button>
        <button class="dom-toggle-btn" data-ol="links">Links</button>
        <button class="dom-toggle-btn" data-ol="images">Images</button>
      </div>
      <button class="btn btn-sm" id="clearAll" style="margin-top:8px;">Clear All</button>
    `;
    $('#togCSS').addEventListener('click',async function(){await sendToContent('toggleDisableCSS');this.classList.toggle('active');});
    $('#togImg').addEventListener('click',async function(){await sendToContent('toggleDisableImages');this.classList.toggle('active');});
    $$('[data-ol]').forEach(b=>b.addEventListener('click',async()=>{await sendToContent('outlineElements',{type:b.dataset.ol});b.classList.toggle('active');}));
    $('#clearAll').addEventListener('click',async()=>{await sendToContent('clearOutlines');$$('.dom-toggle-btn').forEach(b=>b.classList.remove('active'));});
  }

  // --- Storage (EDITABLE + COPYABLE) ---
  async function renderStorage() {
    const data = await sendToContent('getStorage');
    if (!data) { panelContent.innerHTML='<div class="empty-state"><p>Unable</p></div>'; return; }
    const ls = Object.entries(data.localStorage||{});
    const ss = Object.entries(data.sessionStorage||{});

    panelContent.innerHTML = `
      <div class="tabs">
        <button class="tab-btn active" data-st="local">Local (${ls.length})</button>
        <button class="tab-btn" data-st="session">Session (${ss.length})</button>
        <button class="tab-btn" data-st="cookies">Cookies (${data.cookies?.length||0})</button>
      </div>
      <div id="storBody">${renderStorTable(ls, 'localStorage')}</div>
    `;
    $$('[data-st]').forEach(b=>b.addEventListener('click',()=>{
      $$('[data-st]').forEach(x=>x.classList.remove('active'));b.classList.add('active');
      const body=$('#storBody');
      if(b.dataset.st==='local') body.innerHTML=renderStorTable(ls,'localStorage');
      else if(b.dataset.st==='session') body.innerHTML=renderStorTable(ss,'sessionStorage');
      else body.innerHTML = data.cookies?.length ? data.cookies.map((c,i)=>`<div class="data-row" style="position:relative;"><span class="data-value" id="ck${i}" style="cursor:text;">${esc(c)}</span><button class="mini-btn" onclick="navigator.clipboard.writeText(this.parentElement.querySelector('.data-value').textContent)">Copy</button></div>`).join('') : '<div class="empty-state"><p>No cookies</p></div>';
      attachStorageEdit();
    }));
    attachStorageEdit();
  }

  function renderStorTable(entries, storageType) {
    if (!entries.length) return '<div class="empty-state"><p>Empty</p></div>';
    return `<div class="links-table-wrap" style="max-height:250px;"><table class="storage-table"><thead><tr><th>Key</th><th>Value</th><th></th></tr></thead><tbody>${entries.slice(0,50).map(([k,v],i)=>`
      <tr>
        <td style="font-weight:600;">${esc(k)}</td>
        <td><input type="text" class="storage-edit-input" data-storage="${storageType}" data-key="${escA(k)}" value="${escA(v)}" title="${escA(v)}"></td>
        <td><button class="mini-btn" data-copy-val="${escA(v)}">Copy</button></td>
      </tr>
    `).join('')}</tbody></table></div>${entries.length>50?`<div style="font-size:9px;color:var(--text-muted);margin-top:3px;">...and ${entries.length-50} more</div>`:''}`;
  }

  function attachStorageEdit() {
    // Copy buttons
    $$('[data-copy-val]').forEach(b => b.addEventListener('click', () => { copy(b.dataset.copyVal); toast('Copied','success'); }));
    
    // Editable storage - save on Enter or blur
    $$('.storage-edit-input[data-storage]').forEach(input => {
      const originalVal = input.value;
      
      async function saveEdit() {
        if (input.value === originalVal) return;
        const storageType = input.dataset.storage;
        const key = input.dataset.key;
        const newVal = input.value;
        
        try {
          await sendToContent('executeScript', {
            code: `try { ${storageType}.setItem('${key.replace(/'/g,"\\'")}', '${newVal.replace(/'/g,"\\'")}'); 'ok'; } catch(e) { e.message; }`
          });
          toast(`Updated "${key.substring(0,20)}"`, 'success');
        } catch(e) {
          toast('Save failed: ' + e.message, 'error');
        }
      }

      input.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); saveEdit(); input.blur(); } });
      input.addEventListener('blur', saveEdit);
    });
  }

  // --- Utilities ---
  async function renderUtils() {
    panelContent.innerHTML = `
      <div class="tabs">
        <button class="tab-btn active" data-ut="color">Color</button>
        <button class="tab-btn" data-ut="font">Font</button>
        <button class="tab-btn" data-ut="mobile">Mobile</button>
      </div>
      <div id="utilBody">
        <div class="section-title">Color Picker</div>
        <p style="font-size:10px;color:var(--text-secondary);margin-bottom:8px;">Click button, then click any element.</p>
        <button class="btn btn-primary btn-sm" id="startCP">Pick Color</button>
        <div id="colorResult"></div>
      </div>
    `;
    $$('[data-ut]').forEach(b=>b.addEventListener('click',()=>{
      $$('[data-ut]').forEach(x=>x.classList.remove('active'));b.classList.add('active');
      const body=$('#utilBody');
      if(b.dataset.ut==='color') renderUtils();
      else if(b.dataset.ut==='font') body.innerHTML=`<div class="section-title">Font Inspector</div><button class="btn btn-primary btn-sm" id="startFP">Inspect Font</button><div id="fontResult"></div>`;
      else if(b.dataset.ut==='mobile') renderMobileCheck();
    }));
    $('#startCP')?.addEventListener('click',async()=>{
      await sendToContent('startColorPicker');toast('Click any element');
      chrome.runtime.onMessage.addListener(function h(msg){
        if(msg.action==='pickerElementSelected'&&msg.mode==='color'){chrome.runtime.onMessage.removeListener(h);
        const c=msg.data.colors||{};$('#colorResult').innerHTML=`<div class="inspector-result" style="margin-top:8px;">${Object.entries(c).map(([n,v])=>`<div class="color-swatch"><span class="color-preview" style="background:${v}"></span><span>${n}: ${v}</span><button class="mini-btn" data-copy="${v}">Copy</button></div>`).join('')}</div>`;attachCopy();}
      });
    });
    $('#startFP')?.addEventListener('click',async()=>{
      await sendToContent('startInspector');toast('Click any element');
      chrome.runtime.onMessage.addListener(function h(msg){
        if(msg.action==='pickerElementSelected'){chrome.runtime.onMessage.removeListener(h);
        const c=msg.data.computed||{};$('#fontResult').innerHTML=`<div class="inspector-result" style="margin-top:8px;"><div class="data-row"><span class="data-label">Family</span><span class="data-value">${c.fontFamily}</span></div><div class="data-row"><span class="data-label">Size</span><span class="data-value">${c.fontSize}</span></div><div class="data-row"><span class="data-label">Weight</span><span class="data-value">${c.fontWeight}</span></div><div class="data-row"><span class="data-label">Line-H</span><span class="data-value">${c.lineHeight}</span></div><div class="data-row"><span class="data-label">Spacing</span><span class="data-value">${c.letterSpacing}</span></div><button class="btn btn-sm" id="copyFCSS" style="margin-top:6px;">Copy CSS</button></div>`;
        $('#copyFCSS').addEventListener('click',()=>{copy(`font-family: ${c.fontFamily};\nfont-size: ${c.fontSize};\nfont-weight: ${c.fontWeight};\nline-height: ${c.lineHeight};`);toast('Copied','success');});
      }});
    });
  }

  async function renderMobileCheck() {
    const o = await sendToContent('getOverflowInfo') || {};
    $('#utilBody').innerHTML = `
      <div class="section-title">Mobile Check</div>
      <div class="data-row"><span class="data-label">Viewport</span><span class="data-value">${o.viewportWidth||0}px</span></div>
      <div class="data-row"><span class="data-label">Doc Width</span><span class="data-value">${o.documentWidth||0}px</span></div>
      <div class="data-row"><span class="data-label">Overflow</span><span class="data-value"><span class="badge ${o.isOverflowing?'badge-error':'badge-pass'}">${o.isOverflowing?`Yes (+${o.overflow}px)`:'None'}</span></span></div>
      ${o.wideElements?.length?`<div class="section-title">Wide Elements (${o.wideElements.length})</div>${o.wideElements.slice(0,8).map(e=>`<div class="data-row"><span class="data-value">${e.tag}${e.id?'#'+e.id:''} — ${e.width}px</span></div>`).join('')}`:''}
      <a class="btn btn-sm" href="https://pagespeed.web.dev/report?url=${encodeURIComponent(currentTab.url)}" target="_blank" style="margin-top:8px;">PageSpeed Mobile</a>
    `;
  }

  // --- External Tools ---
  async function renderExternal() {
    const u = encodeURIComponent(currentTab?.url||'');
    panelContent.innerHTML = `<div class="ext-tools-grid">
      <a class="ext-tool-link" href="https://pagespeed.web.dev/report?url=${u}" target="_blank"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/></svg><div><div class="ext-tool-name">PageSpeed Insights</div><div class="ext-tool-desc">Performance & CWV</div></div></a>
      <a class="ext-tool-link" href="https://gtmetrix.com/?url=${u}" target="_blank"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg><div><div class="ext-tool-name">GTmetrix</div><div class="ext-tool-desc">Waterfall analysis</div></div></a>
      <a class="ext-tool-link" href="https://search.google.com/test/rich-results?url=${u}" target="_blank"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/></svg><div><div class="ext-tool-name">Rich Results Test</div><div class="ext-tool-desc">Schema validation</div></div></a>
      <a class="ext-tool-link" href="https://validator.w3.org/nu/?doc=${u}" target="_blank"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg><div><div class="ext-tool-name">W3C Validator</div><div class="ext-tool-desc">HTML validation</div></div></a>
      <a class="ext-tool-link" href="https://securityheaders.com/?q=${u}" target="_blank"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg><div><div class="ext-tool-name">Security Headers</div><div class="ext-tool-desc">HTTP header analysis</div></div></a>
      <a class="ext-tool-link" href="https://httpstatus.io/" target="_blank"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg><div><div class="ext-tool-name">HTTP Status</div><div class="ext-tool-desc">Redirect chains</div></div></a>
    </div>`;
  }

  // --- Settings ---
  async function loadSettings() {
    const d = await chrome.storage.local.get(['blockedDomains','siteProfiles','globalCSS']);
    $('#blockedDomainsInput').value = (d.blockedDomains||[]).join('\n');
    $('#globalCSSEditor').value = d.globalCSS || '';
    const profiles = d.siteProfiles||{};
    const list = $('#siteProfilesList');
    const entries = Object.entries(profiles);
    list.innerHTML = entries.length ? entries.map(([k,p])=>`<div class="profile-item"><span class="domain">${esc(k)}</span><span class="badge ${p.enabled?'badge-pass':'badge-warn'}">${p.enabled?'Active':'Off'}</span></div>`).join('') : '<div style="font-size:10px;color:var(--text-muted);">No profiles</div>';
  }

  async function handleExport() {
    const d = await sendBg('exportSettings');
    download(JSON.stringify(d,null,2),'devscope-settings.json','application/json');
    toast('Exported','success');
  }

  async function handleImport(e) {
    const f = e.target.files[0]; if(!f) return;
    try { const t=await f.text(); const d=JSON.parse(t); if(!d.data) throw new Error('Invalid'); await sendBg('importSettings',{data:d}); toast('Imported','success'); loadSettings(); }
    catch(err) { toast('Import failed: '+err.message,'error'); }
    e.target.value='';
  }

  // --- Helpers ---
  function updateToggle() { const t=globalToggle.querySelector('.toggle-track'); globalEnabled?t.classList.add('active'):t.classList.remove('active'); }
  function showRestricted(r) { pageUrl.textContent=currentTab?.url||''; pageTitle.textContent=r; toolGrid.innerHTML=`<div class="restricted-notice" style="grid-column:1/-1;"><svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg><h3>Restricted</h3><p>DevScope cannot run on Chrome internal pages.</p></div>`; }
  function isRestrictedUrl(u) { if(!u) return true; return ['chrome://','chrome-extension://','edge://','about:','devtools://','chrome.google.com/webstore'].some(p=>u.startsWith(p)); }
  function getDomain(u) { try { return new URL(u).hostname; } catch { return ''; } }

  async function sendToContent(action, data={}) {
    if (!currentTab?.id) return null;
    try { return await chrome.tabs.sendMessage(currentTab.id, {target:'content',action,...data}); }
    catch {
      try {
        await chrome.scripting.executeScript({target:{tabId:currentTab.id},files:['shared/messaging.js','content/content.js']});
        await new Promise(r=>setTimeout(r,200));
        return await chrome.tabs.sendMessage(currentTab.id, {target:'content',action,...data});
      } catch { return null; }
    }
  }

  async function sendBg(action, data={}) { return chrome.runtime.sendMessage({target:'background',action,...data}); }
  function copy(t) { navigator.clipboard.writeText(t).catch(()=>{const a=document.createElement('textarea');a.value=t;document.body.appendChild(a);a.select();document.execCommand('copy');a.remove();}); }
  function download(c,n,t) { const b=new Blob([c],{type:t}); const u=URL.createObjectURL(b); const a=document.createElement('a');a.href=u;a.download=n;a.click();URL.revokeObjectURL(u); }
  function toast(m,t='') { const e=document.createElement('div');e.className=`toast ${t}`;e.textContent=m;toastContainer.appendChild(e);setTimeout(()=>{e.style.opacity='0';setTimeout(()=>e.remove(),300);},2500); }
  function esc(s) { if(!s) return ''; const d=document.createElement('div');d.textContent=String(s);return d.innerHTML; }
  function escA(s) { if(!s) return ''; return String(s).replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/'/g,'&#39;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
  function attachCopy() { $$('[data-copy]').forEach(b=>b.addEventListener('click',()=>{copy(b.dataset.copy);toast('Copied','success');})); }

  init();
})();
