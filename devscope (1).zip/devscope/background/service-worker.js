/**
 * DevScope Service Worker (Background Script)
 * Handles context menus, commands, messaging, persistent CSS injection
 */

// --- State ---
const state = {
  globalEnabled: true
};

// --- Initialization ---
chrome.runtime.onInstalled.addListener(async (details) => {
  if (details.reason === 'install') {
    await chrome.storage.local.set({
      globalEnabled: true,
      theme: 'dark',
      siteProfiles: {},
      globalCSS: '',
      blockedDomains: ['facebook.com', 'twitter.com', 'x.com'],
      toolStates: {},
      preferences: {
        defaultTool: 'overview',
        virtualScrollLimit: 500,
        linkOpenLimit: 20
      }
    });
  }
  setupContextMenus();
});

chrome.runtime.onStartup.addListener(() => {
  setupContextMenus();
});

// --- Context Menus ---
function setupContextMenus() {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({ id: 'devscope-open', title: 'Open DevScope', contexts: ['page', 'action'] });
    chrome.contextMenus.create({ id: 'devscope-inspect', title: 'Inspect Element with DevScope', contexts: ['page'] });
    chrome.contextMenus.create({ id: 'devscope-grab-links', title: 'Grab Links', contexts: ['page', 'action'] });
    chrome.contextMenus.create({ id: 'devscope-meta', title: 'Inspect Metadata', contexts: ['page', 'action'] });
    chrome.contextMenus.create({ id: 'devscope-seo', title: 'Analyze SEO', contexts: ['page', 'action'] });
    chrome.contextMenus.create({ id: 'devscope-css', title: 'Open CSS Studio', contexts: ['page', 'action'] });
    chrome.contextMenus.create({ id: 'devscope-color', title: 'Pick Color', contexts: ['page'] });
    chrome.contextMenus.create({ id: 'devscope-pagespeed', title: 'Open PageSpeed Insights', contexts: ['page', 'action'] });
    chrome.contextMenus.create({ id: 'devscope-tech', title: 'Detect Technologies', contexts: ['page', 'action'] });
  });
}

chrome.contextMenus.onClicked.addListener((info, tab) => {
  const handlers = {
    'devscope-open': () => openTabWithDevScope(tab),
    'devscope-inspect': () => sendToContent(tab.id, { action: 'startInspector' }),
    'devscope-grab-links': () => openTabWithDevScope(tab, 'links'),
    'devscope-meta': () => openTabWithDevScope(tab, 'meta'),
    'devscope-seo': () => openTabWithDevScope(tab, 'seo'),
    'devscope-css': () => openTabWithDevScope(tab, 'css'),
    'devscope-color': () => sendToContent(tab.id, { action: 'startColorPicker' }),
    'devscope-pagespeed': () => {
      chrome.tabs.create({ url: `https://pagespeed.web.dev/report?url=${encodeURIComponent(tab.url)}` });
    },
    'devscope-tech': () => openTabWithDevScope(tab, 'technologies')
  };
  handlers[info.menuItemId]?.();
});

// --- Commands ---
chrome.commands.onCommand.addListener(async (command) => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) return;

  const commandMap = {
    'toggle-devscope': () => toggleGlobal(),
    'grab-links': () => openTabWithDevScope(tab, 'links'),
    'inspect-meta': () => openTabWithDevScope(tab, 'meta'),
    'css-picker': () => sendToContent(tab.id, { action: 'startElementPicker' })
  };
  commandMap[command]?.();
});

// --- Messaging ---
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.target === 'background') {
    handleMessage(message, sender).then(sendResponse).catch(err => {
      sendResponse({ error: err.message });
    });
    return true; // async
  }
});

async function handleMessage(message, sender) {
  switch (message.action) {
    case 'getTabInfo': {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab) return { error: 'No active tab' };
      return { url: tab.url, title: tab.title, id: tab.id, favIconUrl: tab.favIconUrl };
    }
    case 'getGlobalState': {
      const data = await chrome.storage.local.get(['globalEnabled']);
      return { enabled: data.globalEnabled !== false };
    }
    case 'setGlobalState': {
      await chrome.storage.local.set({ globalEnabled: message.enabled });
      const tabs = await chrome.tabs.query({ url: ['http://*/*', 'https://*/*'] });
      for (const tab of tabs) {
        sendToContent(tab.id, { action: 'globalStateChanged', enabled: message.enabled }).catch(() => {});
      }
      return { success: true };
    }
    case 'getSiteProfile': {
      return await getSiteProfile(message.domain, message.url);
    }
    case 'saveSiteProfile': {
      await saveSiteProfile(message.profile);
      return { success: true };
    }
    case 'getGlobalCSS': {
      const data = await chrome.storage.local.get(['globalCSS']);
      return { css: data.globalCSS || '' };
    }
    case 'saveGlobalCSS': {
      await chrome.storage.local.set({ globalCSS: message.css });
      // Inject into all open tabs immediately
      const tabs = await chrome.tabs.query({ url: ['http://*/*', 'https://*/*'] });
      for (const tab of tabs) {
        sendToContent(tab.id, { action: 'updateGlobalCSS', css: message.css }).catch(() => {});
      }
      return { success: true };
    }
    case 'injectCSS': {
      return await injectCSSIntoTab(message.tabId, message.css);
    }
    case 'removeInjectedCSS': {
      return await removeInjectedCSSFromTab(message.tabId);
    }
    case 'executeInPage': {
      return await executeInTab(message.tabId, message.code);
    }
    case 'openTool': {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab) await openTabWithDevScope(tab, message.tool);
      return { success: true };
    }
    case 'exportSettings': {
      return await exportAllSettings();
    }
    case 'importSettings': {
      await importSettings(message.data);
      return { success: true };
    }
    case 'getStorage': {
      const keys = message.keys || null;
      return await chrome.storage.local.get(keys);
    }
    case 'setStorage': {
      await chrome.storage.local.set(message.data);
      return { success: true };
    }
    case 'fetchHTML': {
      // Fetch HTML through the proxy API
      return await fetchHTMLViaProxy(message.url);
    }
    default:
      return { error: 'Unknown action: ' + message.action };
  }
}

// --- Fetch HTML via proxy ---
async function fetchHTMLViaProxy(url) {
  try {
    const proxyUrl = `https://html.lr7.workers.dev/?url=${encodeURIComponent(url)}`;
    const response = await fetch(proxyUrl);
    if (!response.ok) {
      return { error: `HTTP ${response.status}`, html: null };
    }
    const html = await response.text();
    return { html, error: null };
  } catch (e) {
    return { error: e.message, html: null };
  }
}

// --- Tab helpers ---
async function sendToContent(tabId, message) {
  return chrome.tabs.sendMessage(tabId, message);
}

async function injectCSSIntoTab(tabId, css) {
  try {
    await chrome.scripting.insertCSS({ target: { tabId }, css, origin: 'USER' });
    return { success: true };
  } catch (e) {
    return { error: e.message };
  }
}

async function removeInjectedCSSFromTab(tabId) {
  try {
    await chrome.scripting.removeCSS({ target: { tabId }, css: '', origin: 'USER' });
    return { success: true };
  } catch (e) {
    return { error: e.message };
  }
}

async function executeInTab(tabId, code) {
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      func: (code) => { try { return { result: eval(code) }; } catch (e) { return { error: e.message }; } },
      args: [code]
    });
    return results?.[0]?.result || {};
  } catch (e) {
    return { error: e.message };
  }
}

// Open DevScope in same tab (for mobile) or as a panel
async function openTabWithDevScope(tab, tool) {
  const popupUrl = chrome.runtime.getURL(`popup/popup.html?tool=${tool || ''}&tabUrl=${encodeURIComponent(tab?.url || '')}&tabTitle=${encodeURIComponent(tab?.title || '')}&tabId=${tab?.id || ''}`);
  
  // On mobile or when requested, open in same tab
  // On desktop, the popup already handles it
  try {
    // Try sending to content first (popup is already open on desktop)
    if (tab?.id) {
      await sendToContent(tab.id, { action: 'activateTool', tool: tool || 'overview' });
      return;
    }
  } catch {
    // Content script not available, open in new tab
    chrome.tabs.create({ url: popupUrl });
  }
}

// --- Global toggle ---
async function toggleGlobal() {
  const data = await chrome.storage.local.get(['globalEnabled']);
  const newState = !data.globalEnabled;
  await chrome.storage.local.set({ globalEnabled: newState });
  const tabs = await chrome.tabs.query({ url: ['http://*/*', 'https://*/*'] });
  for (const tab of tabs) {
    sendToContent(tab.id, { action: 'globalStateChanged', enabled: newState }).catch(() => {});
  }
}

// --- Site Profiles ---
async function getSiteProfile(domain, url) {
  const data = await chrome.storage.local.get(['siteProfiles']);
  const profiles = data.siteProfiles || {};
  return {
    domainProfile: profiles[domain] || createDefaultProfile(domain),
    urlProfile: profiles[url] || null,
    allProfiles: profiles
  };
}

async function saveSiteProfile(profile) {
  const data = await chrome.storage.local.get(['siteProfiles']);
  const profiles = data.siteProfiles || {};
  const key = profile.key || profile.domain;
  profiles[key] = { ...profiles[key], ...profile, updatedAt: Date.now() };
  await chrome.storage.local.set({ siteProfiles: profiles });
}

function createDefaultProfile(domain) {
  return {
    domain,
    enabled: true,
    cssEnabled: true,
    css: '',
    rules: [],
    classRules: [],
    createdAt: Date.now(),
    updatedAt: Date.now()
  };
}

// --- Export/Import ---
async function exportAllSettings() {
  const data = await chrome.storage.local.get(null);
  return { version: '1.1.0', exportedAt: new Date().toISOString(), data };
}

async function importSettings(importData) {
  if (!importData || !importData.data) throw new Error('Invalid import data');
  const allowed = ['siteProfiles', 'blockedDomains', 'toolStates', 'preferences', 'theme', 'globalEnabled', 'globalCSS'];
  const cleanData = {};
  for (const key of allowed) {
    if (key in importData.data) cleanData[key] = importData.data[key];
  }
  await chrome.storage.local.set(cleanData);
}

// --- Listen for tab updates (SPA navigation) ---
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url) {
    try {
      await chrome.tabs.sendMessage(tabId, {
        action: 'urlChanged',
        url: tab.url,
        title: tab.title
      });
    } catch { /* content script may not be injected */ }
  }
});
