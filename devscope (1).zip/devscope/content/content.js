/**
 * DevScope Content Script
 * Handles element inspection, CSS picker, color picker, overlays,
 * page data extraction, and real-time communication with popup/background
 */
(() => {
  'use strict';

  // --- State ---
  let pickerActive = false;
  let pickerMode = 'inspect'; // 'inspect' | 'css' | 'color' | 'class'
  let overlayEl = null;
  let tooltipEl = null;
  let globalEnabled = true;
  let currentInspector = null;

  // --- Initialization ---
  function init() {
    createOverlayElements();
    setupMessageListener();
    observeGlobalState();
  }

  function createOverlayElements() {
    // Highlight overlay
    overlayEl = document.createElement('div');
    overlayEl.id = 'devscope-overlay';
    overlayEl.style.cssText = 'position:fixed;pointer-events:none;z-index:2147483647;border:2px solid #6366f1;background:rgba(99,102,241,0.1);transition:all 0.1s ease;display:none;';
    
    // Tooltip
    tooltipEl = document.createElement('div');
    tooltipEl.id = 'devscope-tooltip';
    tooltipEl.style.cssText = 'position:fixed;pointer-events:none;z-index:2147483647;background:#1e1b4b;color:#e0e7ff;padding:6px 10px;border-radius:8px;font-size:11px;font-family:monospace;max-width:400px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;display:none;box-shadow:0 4px 12px rgba(0,0,0,0.4);border:1px solid rgba(99,102,241,0.3);';
    
    document.documentElement.appendChild(overlayEl);
    document.documentElement.appendChild(tooltipEl);
  }

  function setupMessageListener() {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message.target !== 'content') return;
      
      const handlers = {
        startInspector: () => startPicker('inspect'),
        startElementPicker: () => startPicker('css'),
        startColorPicker: () => startPicker('color'),
        stopPicker: () => stopPicker(),
        getInspectorData: () => sendResponse(getInspectorData(message.selector)),
        getPageData: () => sendResponse(getPageData()),
        getElements: () => sendResponse(getElementsData(message.options)),
        getLinks: () => sendResponse(getLinksData()),
        getImages: () => sendResponse(getImagesData()),
        getPerformance: () => sendResponse(getPerformanceData()),
        getStorage: () => sendResponse(getStorageData()),
        injectCSS: () => { injectCustomCSS(message.css); sendResponse({ success: true }); },
        removeCSS: () => { removeCustomCSS(); sendResponse({ success: true }); },
        addClassToElement: () => {
          const result = addClassToElement(message.selector, message.className);
          sendResponse(result);
        },
        removeClassFromElement: () => {
          const result = removeClassFromElement(message.selector, message.className);
          sendResponse(result);
        },
        getStructuredData: () => sendResponse(getStructuredData()),
        getAccessibility: () => sendResponse(getAccessibilityData()),
        getTechnologies: () => sendResponse(detectTechnologies()),
        getHeaders: () => sendResponse(getHeadersData()),
        getDOMStats: () => sendResponse(getDOMStats()),
        hideElement: () => { hideElement(message.selector); sendResponse({ success: true }); },
        deleteElement: () => { deleteElement(message.selector); sendResponse({ success: true }); },
        editElement: () => { editElement(message.selector, message.html); sendResponse({ success: true }); },
        toggleDisableCSS: () => { toggleDisableCSS(); sendResponse({ success: true }); },
        toggleDisableImages: () => { toggleDisableImages(); sendResponse({ success: true }); },
        outlineElements: () => { outlineElements(message.type); sendResponse({ success: true }); },
        clearOutlines: () => { clearOutlines(); sendResponse({ success: true }); },
        getOverflowInfo: () => sendResponse(getOverflowInfo()),
        globalStateChanged: (msg) => { globalEnabled = msg.enabled; if (!msg.enabled) stopPicker(); },
        urlChanged: () => { /* SPA navigation handled */ },
        activateTool: () => { /* Open popup tool - handled by popup */ },
        executeScript: (msg) => {
          try {
            const result = eval(msg.code);
            sendResponse({ success: true, result });
          } catch(e) {
            sendResponse({ error: e.message });
          }
          return true;
        },
        updateGlobalCSS: (msg) => {
          // Update live global CSS injection
          let el = document.getElementById('devscope-live-global-css');
          if (msg.css && msg.css.trim()) {
            if (!el) {
              el = document.createElement('style');
              el.id = 'devscope-live-global-css';
              el.setAttribute('data-devscope', 'true');
              (document.head || document.documentElement).appendChild(el);
            }
            el.textContent = msg.css;
          } else if (el) {
            el.remove();
          }
          sendResponse({ success: true });
        }
      };

      const handler = handlers[message.action];
      if (handler) {
        const result = handler(message);
        if (result !== undefined) return true; // async
      }
    });
  }

  function observeGlobalState() {
    chrome.storage.local.get(['globalEnabled'], (data) => {
      globalEnabled = data.globalEnabled !== false;
    });
    chrome.storage.onChanged.addListener((changes) => {
      if (changes.globalEnabled) {
        globalEnabled = changes.globalEnabled.newValue !== false;
        if (!globalEnabled) stopPicker();
      }
    });
  }

  // --- Element Picker ---
  function startPicker(mode = 'inspect') {
    if (!globalEnabled) return;
    pickerActive = true;
    pickerMode = mode;
    document.body.style.cursor = 'crosshair';
    document.addEventListener('mousemove', onPickerMouseMove, true);
    document.addEventListener('click', onPickerClick, true);
    document.addEventListener('keydown', onPickerKeydown, true);
  }

  function stopPicker() {
    pickerActive = false;
    document.body.style.cursor = '';
    overlayEl.style.display = 'none';
    tooltipEl.style.display = 'none';
    document.removeEventListener('mousemove', onPickerMouseMove, true);
    document.removeEventListener('click', onPickerClick, true);
    document.removeEventListener('keydown', onPickerKeydown, true);
  }

  function onPickerMouseMove(e) {
    if (!pickerActive) return;
    const el = getElementFromEvent(e);
    if (!el || el === document.documentElement || el === document.body) {
      overlayEl.style.display = 'none';
      tooltipEl.style.display = 'none';
      return;
    }
    
    const rect = el.getBoundingClientRect();
    overlayEl.style.display = 'block';
    overlayEl.style.left = rect.left + 'px';
    overlayEl.style.top = rect.top + 'px';
    overlayEl.style.width = rect.width + 'px';
    overlayEl.style.height = rect.height + 'px';
    
    if (pickerMode === 'color') {
      overlayEl.style.borderColor = '#f59e0b';
      overlayEl.style.background = 'rgba(245,158,11,0.1)';
    } else if (pickerMode === 'css') {
      overlayEl.style.borderColor = '#10b981';
      overlayEl.style.background = 'rgba(16,185,129,0.1)';
    } else {
      overlayEl.style.borderColor = '#6366f1';
      overlayEl.style.background = 'rgba(99,102,241,0.1)';
    }

    const info = getElementInfo(el);
    tooltipEl.style.display = 'block';
    tooltipEl.textContent = info.tag + (info.id ? '#' + info.id : '') + (info.classes.length ? '.' + info.classes.join('.') : '') + ` [${Math.round(rect.width)}×${Math.round(rect.height)}]`;
    
    let tooltipX = e.clientX + 15;
    let tooltipY = e.clientY + 15;
    if (tooltipX + tooltipEl.offsetWidth > window.innerWidth) {
      tooltipX = e.clientX - tooltipEl.offsetWidth - 10;
    }
    if (tooltipY + tooltipEl.offsetHeight > window.innerHeight) {
      tooltipY = e.clientY - tooltipEl.offsetHeight - 10;
    }
    tooltipEl.style.left = tooltipX + 'px';
    tooltipEl.style.top = tooltipY + 'px';
  }

  function onPickerClick(e) {
    if (!pickerActive) return;
    e.preventDefault();
    e.stopPropagation();
    
    const el = getElementFromEvent(e);
    if (!el) return;
    
    const selector = generateSelector(el);
    const data = {
      selector,
      tag: el.tagName.toLowerCase(),
      id: el.id,
      classes: Array.from(el.classList),
      attributes: getAttributes(el),
      rect: el.getBoundingClientRect(),
      computed: getComputedStyleData(el),
      outerHTML: el.outerHTML.substring(0, 5000),
      textContent: el.textContent?.substring(0, 500) || ''
    };

    if (pickerMode === 'color') {
      data.colors = getColors(el);
    }

    chrome.runtime.sendMessage({
      target: 'background',
      action: 'pickerElementSelected',
      mode: pickerMode,
      data
    });

    if (pickerMode === 'inspect') {
      // Stay active for continued inspection
    } else {
      stopPicker();
    }
  }

  function onPickerKeydown(e) {
    if (e.key === 'Escape') {
      stopPicker();
      chrome.runtime.sendMessage({ target: 'background', action: 'pickerCancelled' });
    }
  }

  function getElementFromEvent(e) {
    // Temporarily hide overlay to get element underneath
    overlayEl.style.display = 'none';
    const el = document.elementFromPoint(e.clientX, e.clientY);
    if (pickerActive) overlayEl.style.display = 'block';
    return el;
  }

  // --- Element Info ---
  function getElementInfo(el) {
    const tag = el.tagName.toLowerCase();
    const id = el.id || '';
    const classes = Array.from(el.classList);
    return { tag, id, classes };
  }

  function getAttributes(el) {
    const attrs = {};
    for (const attr of el.attributes) {
      attrs[attr.name] = attr.value;
    }
    return attrs;
  }

  function getComputedStyleData(el) {
    const cs = window.getComputedStyle(el);
    return {
      display: cs.display,
      position: cs.position,
      zIndex: cs.zIndex,
      width: cs.width,
      height: cs.height,
      margin: `${cs.marginTop} ${cs.marginRight} ${cs.marginBottom} ${cs.marginLeft}`,
      padding: `${cs.paddingTop} ${cs.paddingRight} ${cs.paddingBottom} ${cs.paddingLeft}`,
      border: `${cs.borderTopWidth} ${cs.borderStyle || cs.borderTopStyle} ${cs.borderTopColor}`,
      borderTop: cs.borderTop,
      borderRight: cs.borderRight,
      borderBottom: cs.borderBottom,
      borderLeft: cs.borderLeft,
      color: cs.color,
      backgroundColor: cs.backgroundColor,
      fontFamily: cs.fontFamily,
      fontSize: cs.fontSize,
      fontWeight: cs.fontWeight,
      lineHeight: cs.lineHeight,
      letterSpacing: cs.letterSpacing,
      textTransform: cs.textTransform,
      fontStyle: cs.fontStyle,
      textAlign: cs.textAlign,
      textDecoration: cs.textDecoration,
      overflow: cs.overflow,
      opacity: cs.opacity,
      transform: cs.transform,
      flexDirection: cs.flexDirection,
      justifyContent: cs.justifyContent,
      alignItems: cs.alignItems,
      gridTemplateColumns: cs.gridTemplateColumns,
      gridTemplateRows: cs.gridTemplateRows,
      gap: cs.gap
    };
  }

  function getColors(el) {
    const cs = window.getComputedStyle(el);
    return {
      text: cs.color,
      background: cs.backgroundColor,
      borderTop: cs.borderTopColor,
      borderRight: cs.borderRightColor,
      borderBottom: cs.borderBottomColor,
      borderLeft: cs.borderLeftColor
    };
  }

  // --- Selector Generation ---
  function generateSelector(el) {
    if (el.id) return `#${el.id}`;
    
    const path = [];
    let current = el;
    
    while (current && current !== document.body && current !== document.documentElement) {
      let selector = current.tagName.toLowerCase();
      
      if (current.id) {
        path.unshift(`#${current.id}`);
        break;
      }
      
      if (current.className && typeof current.className === 'string') {
        const classes = current.className.trim().split(/\s+/).filter(c => c && !c.startsWith('devscope'));
        if (classes.length > 0) {
          selector += '.' + classes.slice(0, 2).join('.');
        }
      }
      
      // Add nth-child if needed for uniqueness
      const parent = current.parentElement;
      if (parent) {
        const siblings = Array.from(parent.children).filter(c => c.tagName === current.tagName);
        if (siblings.length > 1) {
          const index = siblings.indexOf(current) + 1;
          selector += `:nth-child(${Array.from(parent.children).indexOf(current) + 1})`;
        }
      }
      
      path.unshift(selector);
      current = current.parentElement;
    }
    
    return path.join(' > ');
  }

  // --- Page Data Extraction ---
  function getInspectorData(selector) {
    const el = document.querySelector(selector);
    if (!el) return { error: 'Element not found' };
    return {
      selector,
      tag: el.tagName.toLowerCase(),
      id: el.id,
      classes: Array.from(el.classList),
      attributes: getAttributes(el),
      rect: el.getBoundingClientRect(),
      computed: getComputedStyleData(el),
      outerHTML: el.outerHTML.substring(0, 10000),
      textContent: el.textContent?.substring(0, 1000) || ''
    };
  }

  function getPageData() {
    const url = window.location.href;
    const title = document.title;
    const description = document.querySelector('meta[name="description"]')?.content || '';
    const canonical = document.querySelector('link[rel="canonical"]')?.href || '';
    
    const h1s = document.querySelectorAll('h1');
    const images = document.querySelectorAll('img');
    const links = document.querySelectorAll('a[href]');
    const scripts = document.querySelectorAll('script[src]');
    const stylesheets = document.querySelectorAll('link[rel="stylesheet"]');
    
    const text = document.body?.innerText || '';
    const wordCount = text.trim().split(/\s+/).filter(w => w).length;
    
    return {
      url,
      title,
      description,
      canonical,
      h1Count: h1s.length,
      h1Text: h1s[0]?.textContent?.trim() || '',
      imageCount: images.length,
      linkCount: links.length,
      scriptCount: scripts.length,
      stylesheetCount: stylesheets.length,
      wordCount,
      protocol: window.location.protocol,
      domain: window.location.hostname
    };
  }

  // --- Links Extraction ---
  function getLinksData() {
    const links = [];
    const seen = new Set();
    const anchors = document.querySelectorAll('a[href]');
    const currentOrigin = window.location.origin;
    
    anchors.forEach((a, index) => {
      const href = a.href;
      if (!href || href === '#' || href.startsWith('javascript:void')) return;
      
      let type = 'other';
      if (href.startsWith('mailto:')) type = 'email';
      else if (href.startsWith('tel:')) type = 'phone';
      else if (href.startsWith('javascript:')) type = 'javascript';
      else if (a.download) type = 'download';
      else {
        try {
          const linkUrl = new URL(href);
          type = linkUrl.origin === currentOrigin ? 'internal' : 'external';
        } catch {
          if (href.startsWith('/')) type = 'internal';
        }
      }
      
      const normalized = normalizeURL(href);
      const isDuplicate = seen.has(normalized);
      if (!isDuplicate) seen.add(normalized);
      
      let domain = '';
      try { domain = new URL(href).hostname; } catch {}
      
      links.push({
        url: href,
        text: a.textContent?.trim().substring(0, 200) || '',
        domain,
        type,
        sameOrigin: type === 'internal',
        isDuplicate,
        isHttps: href.startsWith('https:'),
        rel: a.rel || '',
        download: a.download || ''
      });
    });
    
    return { links, total: anchors.length, unique: links.length };
  }

  function normalizeURL(url) {
    try {
      const u = new URL(url);
      u.hash = '';
      // Remove trailing slash
      if (u.pathname.endsWith('/') && u.pathname !== '/') {
        u.pathname = u.pathname.slice(0, -1);
      }
      return u.href;
    } catch {
      return url;
    }
  }

  // --- Images Extraction ---
  function getImagesData() {
    const images = [];
    document.querySelectorAll('img').forEach(img => {
      images.push({
        src: img.src || '',
        alt: img.alt || '',
        width: img.width,
        height: img.height,
        naturalWidth: img.naturalWidth,
        naturalHeight: img.naturalHeight,
        loading: img.loading || '',
        decoding: img.decoding || '',
        srcset: img.srcset || '',
        sizes: img.sizes || '',
        format: getImageFormat(img.src),
        isExternal: img.src && !img.src.startsWith(window.location.origin)
      });
    });
    return { images, total: images.length };
  }

  function getImageFormat(src) {
    if (!src) return 'unknown';
    const ext = src.split('?')[0].split('.').pop().toLowerCase();
    if (['jpg', 'jpeg'].includes(ext)) return 'JPEG';
    if (ext === 'png') return 'PNG';
    if (ext === 'gif') return 'GIF';
    if (ext === 'svg') return 'SVG';
    if (ext === 'webp') return 'WebP';
    if (ext === 'avif') return 'AVIF';
    if (ext === 'ico') return 'ICO';
    return ext.toUpperCase() || 'unknown';
  }

  // --- Performance Data ---
  function getPerformanceData() {
    const perf = performance;
    const nav = perf.getEntriesByType('navigation')[0] || {};
    const paint = perf.getEntriesByType('paint');
    const resources = perf.getEntriesByType('resource');
    
    const lcp = paint.find(p => p.name === 'first-contentful-paint');
    
    return {
      navigation: {
        domContentLoaded: nav.domContentLoadedEventEnd - nav.startTime || 0,
        loadComplete: nav.loadEventEnd - nav.startTime || 0,
        domInteractive: nav.domInteractive - nav.startTime || 0,
        redirectTime: nav.redirectEnd - nav.redirectStart || 0,
        dnsLookup: nav.domainLookupEnd - nav.domainLookupStart || 0,
        tcpConnect: nav.connectEnd - nav.connectStart || 0,
        sslHandshake: nav.connectEnd - nav.secureConnectionStart || 0,
        ttfb: nav.responseStart - nav.requestStart || 0,
        contentDownload: nav.responseEnd - nav.responseStart || 0,
        transferSize: nav.transferSize || 0,
        encodedSize: nav.encodedBodySize || 0,
        decodedSize: nav.decodedBodySize || 0
      },
      paint: {
        fcp: lcp?.startTime || 0
      },
      resources: {
        total: resources.length,
        totalSize: resources.reduce((sum, r) => sum + (r.transferSize || 0), 0),
        byType: getResourceSummary(resources)
      }
    };
  }

  function getResourceSummary(resources) {
    const types = {};
    resources.forEach(r => {
      const type = r.initiatorType || 'other';
      if (!types[type]) types[type] = { count: 0, size: 0 };
      types[type].count++;
      types[type].size += r.transferSize || 0;
    });
    return types;
  }

  // --- Storage Data ---
  function getStorageData() {
    const data = {
      localStorage: {},
      sessionStorage: {},
      cookies: document.cookie.split(';').map(c => c.trim()).filter(c => c),
      indexedDB: [],
      cacheStorage: []
    };
    
    try {
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        data.localStorage[key] = localStorage.getItem(key);
      }
    } catch {}
    
    try {
      for (let i = 0; i < sessionStorage.length; i++) {
        const key = sessionStorage.key(i);
        data.sessionStorage[key] = sessionStorage.getItem(key);
      }
    } catch {}
    
    if (window.indexedDB) {
      // Can't enumerate databases synchronously, note that
      data.indexedDBNote = 'Use DevTools Application tab for full IndexedDB inspection';
    }
    
    if (window.caches) {
      caches.keys().then(keys => { data.cacheStorage = keys; });
    }
    
    return data;
  }

  // --- Structured Data ---
  function getStructuredData() {
    const scripts = document.querySelectorAll('script[type="application/ld+json"]');
    const schemas = [];
    scripts.forEach(script => {
      try {
        const data = JSON.parse(script.textContent);
        schemas.push({
          valid: true,
          data,
          type: data['@type'] || (Array.isArray(data) ? data.map(d => d['@type']) : 'Unknown')
        });
      } catch (e) {
        schemas.push({
          valid: false,
          raw: script.textContent?.substring(0, 500),
          error: e.message
        });
      }
    });
    return { schemas };
  }

  // --- Accessibility Data ---
  function getAccessibilityData() {
    const issues = [];
    
    // Images without alt
    document.querySelectorAll('img').forEach(img => {
      if (!img.hasAttribute('alt')) {
        issues.push({ type: 'error', rule: 'img-alt', message: 'Image missing alt attribute', element: img.src?.substring(0, 100) });
      } else if (img.alt.trim() === '' && !img.getAttribute('aria-hidden')) {
        issues.push({ type: 'warning', rule: 'img-alt-empty', message: 'Image has empty alt (decorative?)', element: img.src?.substring(0, 100) });
      }
    });
    
    // Buttons without accessible name
    document.querySelectorAll('button').forEach(btn => {
      if (!btn.textContent?.trim() && !btn.getAttribute('aria-label') && !btn.getAttribute('aria-labelledby')) {
        issues.push({ type: 'error', rule: 'button-name', message: 'Button has no accessible name', element: btn.outerHTML?.substring(0, 100) });
      }
    });
    
    // Links without accessible name
    document.querySelectorAll('a[href]').forEach(a => {
      if (!a.textContent?.trim() && !a.getAttribute('aria-label') && !a.querySelector('img[alt]')) {
        issues.push({ type: 'error', rule: 'link-name', message: 'Link has no accessible name', element: a.outerHTML?.substring(0, 100) });
      }
    });
    
    // Form controls without labels
    document.querySelectorAll('input, select, textarea').forEach(input => {
      const id = input.id;
      const hasLabel = id && document.querySelector(`label[for="${id}"]`);
      const hasAriaLabel = input.getAttribute('aria-label') || input.getAttribute('aria-labelledby');
      const hasPlaceholder = input.getAttribute('placeholder');
      if (!hasLabel && !hasAriaLabel && input.type !== 'hidden' && input.type !== 'submit') {
        issues.push({ type: 'warning', rule: 'label', message: `Form control without label`, element: input.outerHTML?.substring(0, 100) });
      }
    });
    
    // Language attribute
    const lang = document.documentElement.lang;
    if (!lang) {
      issues.push({ type: 'error', rule: 'html-lang', message: 'Page missing lang attribute' });
    }
    
    // Heading hierarchy
    const headings = document.querySelectorAll('h1, h2, h3, h4, h5, h6');
    let lastLevel = 0;
    headings.forEach(h => {
      const level = parseInt(h.tagName[1]);
      if (level > lastLevel + 1 && lastLevel > 0) {
        issues.push({ type: 'warning', rule: 'heading-order', message: `Heading level skipped: h${lastLevel} → h${level}`, element: h.textContent?.substring(0, 50) });
      }
      lastLevel = level;
    });
    
    // Positive tabindex
    document.querySelectorAll('[tabindex]').forEach(el => {
      const tab = parseInt(el.getAttribute('tabindex'));
      if (tab > 0) {
        issues.push({ type: 'warning', rule: 'tabindex', message: `Positive tabindex found: ${tab}`, element: el.outerHTML?.substring(0, 100) });
      }
    });
    
    return {
      issues,
      total: issues.length,
      errors: issues.filter(i => i.type === 'error').length,
      warnings: issues.filter(i => i.type === 'warning').length
    };
  }

  // --- Technology Detection ---
  function detectTechnologies() {
    const techs = [];
    const html = document.documentElement.outerHTML;
    const scripts = Array.from(document.querySelectorAll('script[src]')).map(s => s.src);
    const metas = Array.from(document.querySelectorAll('meta')).map(m => ({ name: m.name || m.getAttribute('property'), content: m.content }));
    
    // CMS detection
    if (document.querySelector('meta[name="generator"]')) {
      const gen = document.querySelector('meta[name="generator"]').content.toLowerCase();
      if (gen.includes('wordpress')) techs.push({ name: 'WordPress', category: 'CMS', confidence: 'high' });
      if (gen.includes('drupal')) techs.push({ name: 'Drupal', category: 'CMS', confidence: 'high' });
      if (gen.includes('joomla')) techs.push({ name: 'Joomla', category: 'CMS', confidence: 'high' });
    }
    
    if (html.includes('wp-content') || html.includes('wp-includes')) techs.push({ name: 'WordPress', category: 'CMS', confidence: 'high' });
    if (html.includes('shopify.com') || html.includes('cdn.shopify')) techs.push({ name: 'Shopify', category: 'CMS', confidence: 'high' });
    if (html.includes('squarespace') || html.includes('static.squarespace')) techs.push({ name: 'Squarespace', category: 'CMS', confidence: 'medium' });
    if (html.includes('wix.com') || html.includes('static.wixstatic')) techs.push({ name: 'Wix', category: 'CMS', confidence: 'medium' });
    
    // Framework detection
    if (document.querySelector('[data-reactroot]') || document.querySelector('[data-reactid]') || html.includes('_next')) techs.push({ name: 'React', category: 'Frontend', confidence: 'high' });
    if (html.includes('__nuxt') || html.includes('_nuxt')) techs.push({ name: 'Nuxt.js', category: 'Frontend', confidence: 'high' });
    if (html.includes('__next') || document.querySelector('[data-nextjs]')) techs.push({ name: 'Next.js', category: 'Frontend', confidence: 'high' });
    if (document.querySelector('[data-v-') || document.querySelector('[data-vue-')) techs.push({ name: 'Vue.js', category: 'Frontend', confidence: 'high' });
    if (document.querySelector('[ng-]') || document.querySelector('[data-ng-') || html.includes('angular')) techs.push({ name: 'Angular', category: 'Frontend', confidence: 'medium' });
    if (document.querySelector('[class*="svelte-"]') || document.querySelector('[data-svelte-h]')) techs.push({ name: 'Svelte', category: 'Frontend', confidence: 'high' });
    
    // Libraries
    if (window.jQuery || window.$?.fn?.jquery || scripts.some(s => s.includes('jquery'))) techs.push({ name: 'jQuery', category: 'Library', confidence: 'high' });
    if (window.Bootstrap || document.querySelector('.bootstrap') || scripts.some(s => s.includes('bootstrap'))) techs.push({ name: 'Bootstrap', category: 'CSS Framework', confidence: 'medium' });
    if (html.includes('tailwind') || document.querySelector('[class*="tw-"]') || stylesheetsUseTailwind()) techs.push({ name: 'Tailwind CSS', category: 'CSS Framework', confidence: 'medium' });
    
    // Analytics
    if (scripts.some(s => s.includes('google-analytics') || s.includes('gtag') || s.includes('googletagmanager'))) techs.push({ name: 'Google Analytics', category: 'Analytics', confidence: 'high' });
    if (scripts.some(s => s.includes('googletagmanager.com/gtm'))) techs.push({ name: 'Google Tag Manager', category: 'Analytics', confidence: 'high' });
    if (html.includes('fbevents') || scripts.some(s => s.includes('fbevents') || s.includes('facebook'))) techs.push({ name: 'Meta Pixel', category: 'Marketing', confidence: 'high' });
    
    // CDN / Hosting
    if (html.includes('cloudflare') || document.querySelector('link[href*="cloudflare"]')) techs.push({ name: 'Cloudflare', category: 'CDN', confidence: 'medium' });
    if (scripts.some(s => s.includes('vercel'))) techs.push({ name: 'Vercel', category: 'Hosting', confidence: 'medium' });
    if (scripts.some(s => s.includes('netlify'))) techs.push({ name: 'Netlify', category: 'Hosting', confidence: 'medium' });
    
    // Payments
    if (scripts.some(s => s.includes('stripe') || s.includes('js.stripe'))) techs.push({ name: 'Stripe', category: 'Payment', confidence: 'high' });
    if (scripts.some(s => s.includes('paypal'))) techs.push({ name: 'PayPal', category: 'Payment', confidence: 'high' });
    
    // Backend signals
    if (html.includes('laravel') || document.querySelector('meta[name="csrf-token"]') && html.includes('laravel')) techs.push({ name: 'Laravel', category: 'Backend', confidence: 'medium' });
    if (document.querySelector('meta[name="csrf-token"]') && !html.includes('laravel') && !html.includes('wordpress')) techs.push({ name: 'CSRF Protection', category: 'Backend Signal', confidence: 'low' });
    
    // Firebase / Supabase
    if (scripts.some(s => s.includes('firebase')) || window.firebase) techs.push({ name: 'Firebase', category: 'Backend', confidence: 'high' });
    if (scripts.some(s => s.includes('supabase'))) techs.push({ name: 'Supabase', category: 'Backend', confidence: 'high' });
    
    // Fonts
    if (html.includes('fonts.googleapis.com') || html.includes('fonts.gstatic.com')) techs.push({ name: 'Google Fonts', category: 'Fonts', confidence: 'high' });
    if (html.includes('use.typekit.net') || html.includes('fonts.adobe.com')) techs.push({ name: 'Adobe Fonts', category: 'Fonts', confidence: 'high' });
    
    return { technologies: techs, total: techs.length };
  }

  function stylesheetsUseTailwind() {
    const sheets = document.querySelectorAll('style, link[rel="stylesheet"]');
    for (const sheet of sheets) {
      if (sheet.tagName === 'LINK' && sheet.href?.includes('tailwind')) return true;
    }
    // Check for Tailwind utility classes
    return document.querySelector('[class*="flex-"]') && document.querySelector('[class*="px-"]') !== null;
  }

  // --- Headers Data ---
  function getHeadersData() {
    return {
      url: window.location.href,
      documentURL: document.documentURI,
      referrer: document.referrer,
      protocol: window.location.protocol,
      securityState: window.isSecureContext ? 'secure' : 'insecure',
      hostname: window.location.hostname,
      port: window.location.port,
      pathname: window.location.pathname,
      search: window.location.search
    };
  }

  // --- DOM Stats ---
  function getDOMStats() {
    const all = document.querySelectorAll('*');
    return {
      totalElements: all.length,
      depth: getDOMDepth(document.documentElement),
      externalScripts: document.querySelectorAll('script[src]').length,
      inlineScripts: document.querySelectorAll('script:not([src])').length,
      stylesheets: document.querySelectorAll('link[rel="stylesheet"]').length,
      inlineStyles: document.querySelectorAll('style').length,
      images: document.querySelectorAll('img').length,
      iframes: document.querySelectorAll('iframe').length,
      forms: document.querySelectorAll('form').length,
      buttons: document.querySelectorAll('button, input[type="button"], input[type="submit"]').length,
      links: document.querySelectorAll('a[href]').length,
      headings: {
        h1: document.querySelectorAll('h1').length,
        h2: document.querySelectorAll('h2').length,
        h3: document.querySelectorAll('h3').length,
        h4: document.querySelectorAll('h4').length,
        h5: document.querySelectorAll('h5').length,
        h6: document.querySelectorAll('h6').length
      }
    };
  }

  function getDOMDepth(el) {
    let depth = 0;
    let current = el;
    while (current) {
      depth++;
      current = current.firstElementChild;
      // Actually need to find deepest child
    }
    // Recursive approach
    function maxDepth(node) {
      if (!node || !node.firstElementChild) return 1;
      let max = 0;
      for (const child of node.children) {
        max = Math.max(max, maxDepth(child));
      }
      return max + 1;
    }
    return maxDepth(el);
  }

  // --- CSS Injection ---
  let customStyleEl = null;
  function injectCustomCSS(css) {
    if (!customStyleEl) {
      customStyleEl = document.createElement('style');
      customStyleEl.id = 'devscope-custom-css';
      customStyleEl.setAttribute('data-devscope', 'true');
      (document.head || document.documentElement).appendChild(customStyleEl);
    }
    customStyleEl.textContent = css;
  }

  function removeCustomCSS() {
    if (customStyleEl) {
      customStyleEl.remove();
      customStyleEl = null;
    }
  }

  // --- Class Operations ---
  function addClassToElement(selector, className) {
    const el = document.querySelector(selector);
    if (!el) return { error: 'Element not found' };
    el.classList.add(className);
    return { success: true, classes: Array.from(el.classList) };
  }

  function removeClassFromElement(selector, className) {
    const el = document.querySelector(selector);
    if (!el) return { error: 'Element not found' };
    el.classList.remove(className);
    return { success: true, classes: Array.from(el.classList) };
  }

  // --- DOM Utilities ---
  function hideElement(selector) {
    const el = document.querySelector(selector);
    if (el) el.style.display = 'none';
  }

  function deleteElement(selector) {
    const el = document.querySelector(selector);
    if (el) el.remove();
  }

  function editElement(selector, html) {
    const el = document.querySelector(selector);
    if (el) el.innerHTML = html;
  }

  let disabledCSS = false;
  function toggleDisableCSS() {
    disabledCSS = !disabledCSS;
    const id = 'devscope-disable-css';
    let style = document.getElementById(id);
    if (disabledCSS) {
      if (!style) {
        style = document.createElement('style');
        style.id = id;
        style.textContent = 'body * { visibility: hidden !important; } body { visibility: visible !important; }';
        document.head.appendChild(style);
      }
    } else {
      style?.remove();
    }
  }

  let disabledImages = false;
  function toggleDisableImages() {
    disabledImages = !disabledImages;
    const id = 'devscope-disable-images';
    let style = document.getElementById(id);
    if (disabledImages) {
      if (!style) {
        style = document.createElement('style');
        style.id = id;
        style.textContent = 'img { visibility: hidden !important; }';
        document.head.appendChild(style);
      }
    } else {
      style?.remove();
    }
  }

  function outlineElements(type) {
    clearOutlines();
    let selector = '';
    let color = '#6366f1';
    switch (type) {
      case 'headings': selector = 'h1, h2, h3, h4, h5, h6'; color = '#8b5cf6'; break;
      case 'links': selector = 'a[href]'; color = '#3b82f6'; break;
      case 'images': selector = 'img'; color = '#10b981'; break;
      case 'buttons': selector = 'button, input[type="button"], input[type="submit"]'; color = '#f59e0b'; break;
      case 'forms': selector = 'form, input, select, textarea'; color = '#ef4444'; break;
      case 'all': selector = '*'; color = '#6366f1'; break;
      default: return;
    }
    
    const style = document.createElement('style');
    style.id = 'devscope-outline';
    style.textContent = `${selector} { outline: 2px solid ${color} !important; outline-offset: 1px !important; }`;
    document.head.appendChild(style);
  }

  function clearOutlines() {
    document.getElementById('devscope-outline')?.remove();
  }

  // --- Overflow Detection ---
  function getOverflowInfo() {
    const docWidth = document.documentElement.scrollWidth;
    const viewportWidth = window.innerWidth;
    const isOverflowing = docWidth > viewportWidth;
    
    const wideElements = [];
    if (isOverflowing) {
      document.querySelectorAll('*').forEach(el => {
        const rect = el.getBoundingClientRect();
        if (rect.right > viewportWidth && rect.width > viewportWidth * 0.5) {
          wideElements.push({
            tag: el.tagName.toLowerCase(),
            id: el.id,
            classes: Array.from(el.classList).join(' '),
            width: Math.round(rect.width),
            selector: generateSelector(el)
          });
        }
      });
    }
    
    // Check for small fonts
    const smallFonts = [];
    document.querySelectorAll('*').forEach(el => {
      const fs = parseFloat(window.getComputedStyle(el).fontSize);
      if (fs < 12 && el.textContent?.trim()) {
        smallFonts.push({
          tag: el.tagName.toLowerCase(),
          fontSize: fs,
          text: el.textContent.trim().substring(0, 50),
          selector: generateSelector(el)
        });
      }
    });
    
    return {
      isOverflowing,
      documentWidth: docWidth,
      viewportWidth,
      overflow: docWidth - viewportWidth,
      wideElements: wideElements.slice(0, 50),
      smallFonts: smallFonts.slice(0, 50)
    };
  }

  // --- Element data with options ---
  function getElementsData(options = {}) {
    const results = [];
    let selector = '*';
    switch (options.type) {
      case 'headings': selector = 'h1, h2, h3, h4, h5, h6'; break;
      case 'links': selector = 'a[href]'; break;
      case 'images': selector = 'img'; break;
      case 'buttons': selector = 'button, input[type="button"], input[type="submit"]'; break;
      case 'forms': selector = 'form, input, select, textarea'; break;
      default: selector = options.selector || '*';
    }
    
    const elements = document.querySelectorAll(selector);
    const limit = options.limit || 1000;
    
    elements.forEach((el, i) => {
      if (i >= limit) return;
      results.push({
        index: i,
        tag: el.tagName.toLowerCase(),
        id: el.id || undefined,
        classes: el.className ? Array.from(el.classList) : [],
        rect: el.getBoundingClientRect(),
        selector: generateSelector(el),
        text: el.textContent?.substring(0, 100)?.trim() || ''
      });
    });
    
    return { elements: results, total: elements.length };
  }

  // --- Start ---
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
