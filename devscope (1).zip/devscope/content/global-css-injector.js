/**
 * DevScope Global CSS Injector
 * Runs at document_start on every page to inject user's saved global CSS
 * and site-specific CSS before the page renders (minimizes FOUC)
 */
(() => {
  'use strict';

  // Read global CSS and site-specific CSS from storage
  chrome.storage.local.get(['globalEnabled', 'globalCSS', 'siteProfiles'], (data) => {
    if (data.globalEnabled === false) return;

    const cssChunks = [];

    // 1. Global CSS (applies to ALL sites)
    if (data.globalCSS && data.globalCSS.trim()) {
      cssChunks.push(data.globalCSS);
    }

    // 2. Site-specific CSS from profiles
    const profiles = data.siteProfiles || {};
    const hostname = window.location.hostname;
    const fullUrl = window.location.href;

    for (const [key, profile] of Object.entries(profiles)) {
      if (!profile.enabled || !profile.cssEnabled || !profile.css) continue;

      // Match by domain or exact URL or URL pattern
      const isMatch =
        key === hostname ||
        key === fullUrl ||
        key === 'global' ||
        matchUrlPattern(key, fullUrl);

      if (isMatch && profile.css.trim()) {
        cssChunks.push(`/* DevScope: ${key} */\n${profile.css}`);
      }
    }

    if (cssChunks.length > 0) {
      const style = document.createElement('style');
      style.id = 'devscope-global-css';
      style.setAttribute('data-devscope', 'true');
      style.textContent = cssChunks.join('\n\n');

      // Inject as early as possible
      const target = document.head || document.documentElement;
      if (target) {
        target.appendChild(style);
      } else {
        // document_start may fire before head exists
        document.addEventListener('DOMContentLoaded', () => {
          (document.head || document.documentElement).appendChild(style);
        });
      }
    }

    // 3. Apply saved class rules
    const classRules = [];
    for (const [key, profile] of Object.entries(profiles)) {
      if (!profile.enabled || !profile.classRules?.length) continue;
      const isMatch =
        key === hostname ||
        key === fullUrl ||
        key === 'global' ||
        matchUrlPattern(key, fullUrl);
      if (isMatch) {
        classRules.push(...profile.classRules.filter(r => r.enabled));
      }
    }

    if (classRules.length > 0) {
      applyClassRules(classRules);
    }
  });

  function matchUrlPattern(pattern, url) {
    // Simple wildcard matching
    if (pattern.includes('*')) {
      const regex = new RegExp('^' + pattern.replace(/\*/g, '.*') + '$');
      return regex.test(url);
    }
    return false;
  }

  function applyClassRules(rules) {
    function apply() {
      for (const rule of rules) {
        try {
          const elements = document.querySelectorAll(rule.selector);
          elements.forEach(el => {
            if (rule.action === 'addClass' && !el.classList.contains(rule.className)) {
              el.classList.add(rule.className);
            } else if (rule.action === 'removeClass') {
              el.classList.remove(rule.className);
            }
          });
        } catch {}
      }
    }

    // Apply when DOM is ready
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', apply);
    } else {
      apply();
    }

    // Observe for SPA / dynamic changes (debounced)
    let timer;
    const observer = new MutationObserver(() => {
      clearTimeout(timer);
      timer = setTimeout(apply, 150);
    });
    
    if (document.documentElement) {
      observer.observe(document.documentElement, { childList: true, subtree: true });
    } else {
      document.addEventListener('DOMContentLoaded', () => {
        observer.observe(document.documentElement, { childList: true, subtree: true });
      });
    }
  }
})();
