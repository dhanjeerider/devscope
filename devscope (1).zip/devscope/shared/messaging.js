/**
 * DevScope Shared Messaging Library
 * Provides typed message passing between extension components
 */
const DevScopeMessaging = (() => {
  const pendingRequests = new Map();
  let requestId = 0;

  function sendToBackground(action, data = {}) {
    return chrome.runtime.sendMessage({
      target: 'background',
      action,
      ...data
    });
  }

  function sendToTab(tabId, action, data = {}) {
    return chrome.tabs.sendMessage(tabId, {
      target: 'content',
      action,
      ...data
    });
  }

  function isRestrictedUrl(url) {
    if (!url) return true;
    const restricted = [
      'chrome://', 'chrome-extension://', 'edge://',
      'about:', 'devtools://', 'chrome.google.com/webstore'
    ];
    return restricted.some(prefix => url.startsWith(prefix));
  }

  function getDomain(url) {
    try {
      return new URL(url).hostname;
    } catch {
      return '';
    }
  }

  return { sendToBackground, sendToTab, isRestrictedUrl, getDomain };
})();
