/**
 * DevScope Options Page
 */
(async () => {
  'use strict';

  const $ = (sel) => document.querySelector(sel);

  // Load current settings
  const data = await chrome.storage.local.get(['theme', 'blockedDomains', 'preferences']);
  
  $('#theme').value = data.theme || 'dark';
  $('#blockedDomains').value = (data.blockedDomains || ['facebook.com', 'twitter.com', 'x.com']).join('\n');
  $('#defaultTool').value = data.preferences?.defaultTool || 'overview';

  // Save on change
  $('#theme').addEventListener('change', async (e) => {
    await chrome.storage.local.set({ theme: e.target.value });
    showStatus('Theme updated', 'success');
  });

  $('#defaultTool').addEventListener('change', async (e) => {
    const prefs = data.preferences || {};
    prefs.defaultTool = e.target.value;
    await chrome.storage.local.set({ preferences: prefs });
    showStatus('Default tool updated', 'success');
  });

  let saveTimeout;
  $('#blockedDomains').addEventListener('input', () => {
    clearTimeout(saveTimeout);
    saveTimeout = setTimeout(async () => {
      const domains = $('#blockedDomains').value.split('\n').map(d => d.trim()).filter(d => d);
      await chrome.storage.local.set({ blockedDomains: domains });
      showStatus('Blocked domains saved', 'success');
    }, 500);
  });

  // Export
  $('#exportBtn').addEventListener('click', async () => {
    const allData = await chrome.storage.local.get(null);
    const exportData = {
      version: '1.0.0',
      exportedAt: new Date().toISOString(),
      data: allData
    };
    const json = JSON.stringify(exportData, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'devscope-settings.json';
    a.click();
    URL.revokeObjectURL(url);
    showStatus('Settings exported', 'success');
  });

  // Import
  $('#importBtn').addEventListener('click', () => $('#importFile').click());
  $('#importFile').addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    try {
      const text = await file.text();
      const importData = JSON.parse(text);
      if (!importData.data) throw new Error('Invalid format');
      
      // Validate and import only safe keys
      const allowed = ['siteProfiles', 'blockedDomains', 'toolStates', 'preferences', 'theme', 'globalEnabled'];
      const cleanData = {};
      for (const key of allowed) {
        if (key in importData.data) cleanData[key] = importData.data[key];
      }
      await chrome.storage.local.set(cleanData);
      showStatus('Settings imported successfully', 'success');
      
      // Reload page to reflect changes
      setTimeout(() => location.reload(), 1000);
    } catch (err) {
      showStatus('Import failed: ' + err.message, 'error');
    }
    e.target.value = '';
  });

  // Clear
  $('#clearBtn').addEventListener('click', async () => {
    if (!confirm('Are you sure you want to clear all DevScope data? This cannot be undone.')) return;
    await chrome.storage.local.clear();
    showStatus('All data cleared', 'success');
    setTimeout(() => location.reload(), 1000);
  });

  function showStatus(msg, type) {
    const el = $('#statusMsg');
    el.textContent = msg;
    el.className = 'status-msg ' + type;
    setTimeout(() => { el.className = 'status-msg'; }, 3000);
  }
})();
